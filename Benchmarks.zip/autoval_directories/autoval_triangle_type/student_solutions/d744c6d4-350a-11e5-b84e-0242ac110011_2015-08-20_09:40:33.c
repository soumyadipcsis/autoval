/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    if(a*a+b*b==c*c||b*b+c*c==a*a||a*a+c*c==b*b)//condition for a                                                   Right Angled triangle                                              , any one of the above                                               conditions should satisfy. 
       {
            return 1;
       } 

    else if(a+b<c||b+c<a||c+a<b)//Triangle Inequality,sum of two sides                                     should be greater than third side
       {
            return -1;
       }
     
    else if (a*a+b*b>c*c && b*b+c*c>a*a && a*a+c*c>b*b)//condition for                                     an angle to be acute ,For a                                            triangle to be acute all of the                                       above condition should satisfy so we                                         use && sign
       {
             return 2;
            
        }
     else if(a*a/2<b*b+c*c<a*a||b*b/2<a*a+c*c<b*b||c*c/2<a*a+b*b<c*c)//                                     condition for a triangle to be                                         obtuse , any one of the above                                             condition should satisfy
    {
            return 3;
        
    }
  
   
    //return 0;
}

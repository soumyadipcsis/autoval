/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a; int b; int c; 
    
    scanf("%d%d%d",&a,&b,&c);  // for input
    
    if (a+b<=c||b+c<=a||c+a<=b)  // condition for invalid triangle
    {    
        
        return -1; 
    }
    
    else if (a*a+b*b==c*c)          // condition for right triangle
    {   
        
        return 1;
    }
    else if(a*a+b*b>c*c)          //condition for acute triangle
    {  
        
        return 2;
    }
    else if(a*a+b*b<c*c)          //condition for obtuse triangle
    {  
        return 3;
    }
    
    
    
    
    
    
  //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c,ls,ss1,ss2;//declaring variables
    scanf("%d %d %d",&a,&b,&c);//assigning the values of the sides of      triangle
    if(a>=b)//checking the largest side and assigning it as ls and the     other sides as ss1 and ss2
    {
        if(a>=c)
        {
            ls=a;
            ss1=b;
            ss2=c;
        }
        else
        {
            ls=c;
            ss1=a;
            ss2=b;
        }    
            
    }
    else
    {
        if(b>c)
        {
            ls=b;
            ss1=a;
            ss2=c;
        } 
        else
        {
            ls=c;
            ss1=a;
            ss2=b;
        }
    }
    if((a+b)>c && (a+c)>b && (b+c)>a)//checking if the triangle exists
    {
        if((ss1*ss1)+(ss2*ss2)==(ls*ls))//checking if the triangle is          right
            return 1;
        else if((ss1*ss1)+(ss2*ss2)<(ls*ls))//checking if the triangle         is obtuse
            return 3;
        else//checking if the triangle is acute
            return 2;
    }
    else
        return -1;//printing invalid triangle when the         triangle doesnt exists
    //return 0;
}
/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
   if(a+b>c && a+c>b && b+c>a)
   {
       if((a>b && a>c) || (a>b && a==c) || (a>c && a==b))
         {
          if(a*a>b*b+c*c) {return 3;}
          if(a*a==b*b+c*c){return 1;}
          if(a*a<b*b+c*c) {return 2;}
         }   
      if((b>a && b>c) || (b>a && b==c) )
         {
          if(b*b>a*a+c*c) {return 3;}
          if(b*b==a*a+c*c){return 1;}
          if(b*b<a*a+c*c) {return 2;}
         }
      if((c>b && c>a))
         {
          if(c*c>b*b+a*a) {return 3;}
          if(c*c==b*b+a*a){return 1;}
          if(c*c<b*b+a*a) {return 2;}
         } 
        if(a==b && b==c) {return 2;}
   }
   else {return -1;}
    //return 0;
}
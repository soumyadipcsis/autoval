/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf ("%d%d%d",&a,&b,&c);
    
    
    if ((a<=b) && (b<=c) && a!=0 && b!=0 && c!=0) /*when a<=b<=c*/
    {
        if (c*c == a*a + b*b)           /* by pythagoras theorem*/       
           return 1;
           
        else if (c*c < a*a + b*b)       /* by cosine formula*/
           return 2;
           
        else if (c >= a + b)            /*condition for triangles*/
           return -1;
           
        else
           return 3;
    }
    
    
    else if ((a<=c) && (c<=b) && a!=0 && b!=0 && c!=0)
    {
        if (b*b == a*a + c*c)
           return 1;
           
        else if (b*b < a*a + c*c)
           return 2;
           
        else if (b >= a + c)
           return -1; 
           
        else
           return 3;
    } 
    
    
    else if ((b<=a) && (a<=c) && a!=0 && b!=0 && c!=0)
    {
        if (c*c == a*a + b*b)
           return 1;
           
        else if (c*c < a*a + b*b)
           return 2;
           
        else if (c >= a + b)
           return -1;
           
        else
           return 3;
    } 
    
    else if ((b<=c) && (c<=a) && a!=0 && b!=0 && c!=0)
    {
        if (a*a == c*c + b*b)
           return 1;
           
        else if (a*a < c*c + b*b)
           return 2;
           
        else if (a >= c + b)
           return -1;
           
        else
           return 3;
    }
    
    
    else if ((c<=a) && (a<=b) && a!=0 && b!=0 && c!=0)
    {
        if (b*b == a*a + c*c)
           return 1;
           
        else if (b*b < a*a + c*c)
           return 2;
           
        else if (b >= a + c)
           return -1;   
           
        else
           return 3;
    }
    
    
    else if ((c<=b) && (b<=a) && a!=0 && b!=0 && c!=0)
    {
        if (a*a == b*b + c*c)
           return 1;
           
        else if (a*a < b*b + c*c)
           return 2;
           
        else if (a >= b + c)
           return -1; 
           
        else
           return 3;
    }
    
    
    if (a==0 || b==0 || c==0)   /*sides of triangles cant be zero*/
    
       return -1;
       
    //return 0;
}
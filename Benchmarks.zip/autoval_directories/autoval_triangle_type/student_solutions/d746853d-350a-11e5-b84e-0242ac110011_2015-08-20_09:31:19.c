/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c){
            int a,b,c;                      //variable declaration
            
        
            scanf("%d %d %d",&a,&b,&c);     /*storage in memory*/


    if(a*a+b*b==c*c || a*a+c*c==b*b || b*b+c*c==a*a)   /*decision control instruction*/
     
                 {return 1;}          /*executeing decision*/
                
            else if(a*a+b*b-c*c>0 && a*a+c*c-b*b>0 && c*c+b*b-a*a>0)                                                    /*decision control instruction*/
    
                        {return 2;}    /*executing decision*/
                
        else if(a*a+b*b-c*c>2*a*b || a*a+c*c-b*b>2*a*c || b*b+c*c-a*a>2*b*c)
                            /*decision control instruction*/
                            
                    {return -1;}       /*executing decision*/
                
     else
     
          {return 3;}
        
                    
                
                //return 0;  /*returning value to function*/
                
    
}
    

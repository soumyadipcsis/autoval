/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
  int a,b,c,A,B,C;
  scanf("%d %d %d",&a,&b,&c);
  A=a*a;
  B=b*b;
  C=c*c;
  if(((a+b)>c)&&((b+c)>a)&&((c+a)>b)&&a>0&&b>0&&c>0)/* It is the condition that for the given sides triangle will exist or not*/
  {
      if(((A+B)>C)&&((C+B)>A)&&((A+C)>B))/*this condition proves that the three angles are acute.*/
      {
          return 2;
      }
      else if(((A+B)==C)||((C+B)==A)||((A+C)==B))/*this condition  shows that one of the angle is right angle.*/
      {
          return 1;
      }
      else if(((A+B)<C)||((C+B)<A)||((A+C)<B))/*this condition  shows that one of the angle is right obtuse angle.*/
      {
          return 3;
      }
  }
  else /* if the first condition not satisfies then triangle not possible*/
  {
      return -1;
  }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a1,b1,c1,a,b,c;
    scanf("%d %d %d",&a1,&b1,&c1);// Fill this area with your code.
    if(a1>=b1 && a1>=c1){//if a1 is greatest, c becomes the greatest
        c=a1;
        b=c1;
        a=b1;
        
    }
    else if(b1>=a1 && b1>=c1)//if b1 is greatest,c becomes the greatest
    {
        c=b1;
        a=c1;
        b=a1;
    }
    
    else
    {
        a=a1;
        b=b1;
        c=c1;
    }    
    
        if(c>=a+b)// sum of two sides is more than third,invalid 
            return -1;
        else
        {
            if(c*c>a*a + b*b)// condition for obtuse triangle
                return 3;
            else if(c*c==a*a+b*b)// condition for right triangle
            {
                return 1;
            }
            else{
                return 2;
            }
        }
    
    //return 0;
}
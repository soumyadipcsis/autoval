/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
   int a,b,c;
   scanf("%d %d %d",&a,&b,&c);
   if(a+b>c && b+c>a && a+c>b){//cheking whether tringl is pssibl or nt
   if(a>=b && a>=c){//cheking whether 'a' is hypo. or not
       if((a*a)==(b*b+c*c)){//cheking whether rigt tringl (p.theorem)
          return 1;
       }  
       else if((a*a)>(b*b+c*c)){//cheking whther obtus tringl p.theorem
          return 3;
       }
       else if((a*a)<(b*b+c*c)){
          return 2;
       }
       else{
           return -1;
       }
   }
   else if(b>=c && b>=a){//cheking whether 'b' is hypo. or not
         if((b*b)==(a*a+c*c)){//cheking whether rigt tringl {p.theorem}
          return 1;
         }  
         else if((b*b)>(a*a+c*c)){//similr explanatn
          return 3;
         }
         else if((b*b)<(a*a+c*c)){//similr explantn
          return 2;
       }
       else{
           return -1;
       }
   }
   else if(c>=b && c>=a){        
        if((c*c)==(a*a+b*b)){//cheking whether rigt tringl (p.theorem)
          return 1;
        }  
        else if((c*c)>(a*a+b*b)){//similr explantn
          return 3;
        }
        else if((c*c)<(b*b+a*a)){//similr explantn
          return 2;
        }
       else{
           return -1;
        }

       
   }
   }
   else{
       return -1;
   }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;
#include<math.h>

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c,big_s;
    scanf("%d %d %d",&a,&b,&c); //Stored Side Length as Integers
    
    if (((a+b)>c) && ((a+c)>b) && ((b+c)>a)) // Triangle Sum Property
    {
        if ((a>c) && (a>b))    //Identifying Biggest Number
        { big_s=0;}            // If side a is largest
        else if ((b>a) && (b>c))
        { big_s=1;}            //If side b is largest
        else
        { big_s=2;}            //If side c is largest
        
        switch(big_s)          //Computation for Triangle Type
        
        {
        
        case 0 :                     //executes if a is largest side
        {
            if ((b*b)+(c*c)<(a*a))  //pythagorean corollary
            {return 3;}
            else if ((b*b)+(c*c)==(a*a)) //pythagoras theorem
            {return 1;}
            else
            {return 2;}
            break;
        }
    
        case 1 :
        {
            if ((a*a)+(c*c)<(b*b))    //executes if b is largest
            {return 3;}
            else if ((a*a)+(c*c)==(b*b)) //geometrical property of tr.
            {return 1;}
            else
            {return 2;}
            break;
        }
        
        case 2 :
        {
            if ((b*b)+(a*a)<(c*c)) //executes if c is largest side
            {return 3;}
            else if ((b*b)+(a*a)==(c*c))
            {return 1;}
            else
            {return 2;}
            break;
        }
        
        default : {return -1;} //if not valid tr.
        
        }
    
            
            
            
            
            
            
    }
    
    else
    {
        return -1; //message if not valid triangle
    }
    
    
    //return 0;
}
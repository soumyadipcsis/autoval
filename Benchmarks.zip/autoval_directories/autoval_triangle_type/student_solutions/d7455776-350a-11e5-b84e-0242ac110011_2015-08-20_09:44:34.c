/*compile-errors:e156_271814.c:18:5: warning: add explicit braces to avoid dangling else [-Wdangling-else]
    else if ((((a*a)+(b*b))<c*c)&& ((a+b)>c))
    ^
e156_271814.c:27:5: warning: add explicit braces to avoid dangling else [-Wdangling-else]
    else if ((((c*c)+(b*b))<a*a)&& ((a+b)>c))
    ^
e156_271814.c:36:5: warning: add explicit braces to avoid dangling else [-Wdangling-else]
    else if ((((a*a)+(c*c))<b*b)&& ((a+b)>c))
    ^
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c; // a,b,c represent three sides of a triangle
    scanf("%d%d%d",&a,&b,&c);
    
    if (a+b<=c||b+c<=a||c+a<=b)
    
    return -1;
    
    else
    {if (c>=a && c>=b)
    if ((((a*a)+(b*b))>c*c)&& ((a+b)>c))
    return 2;
    else if ((((a*a)+(b*b))<c*c)&& ((a+b)>c))
    return 3;
    else if ((((a*a)+(b*b))==c*c)&& ((a+b)>c))
    return 1;
    
    if (a>=b && a>=c)
    
    if ((((c*c)+(b*b))>a*a)&& ((a+b)>c))
    return 2;
    else if ((((c*c)+(b*b))<a*a)&& ((a+b)>c))
    return 3;
    else if ((((c*c)+(b*b))==a*a)&& ((a+b)>c))
    return 1;
    
    if (b>=a && b>=c)
    
    if ((((a*a)+(c*c))>b*b)&& ((a+b)>c))
    return 2;
    else if ((((a*a)+(c*c))<b*b)&& ((a+b)>c))
    return 3;
    else if ((((a*a)+(c*c))==b*b)&& ((a+b)>c))
    return 1;}
    
    //return 0;
}

/*compile-errors:e156_271776.c:5:14: warning: unused variable 't' [-Wunused-variable]
   int a,b,c,t;
             ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
   int a,b,c,t;
   scanf("%d%d%d",&a,&b,&c);
   if(a<b) {
       if(a<c){
        return 1; }
   else{
       return 2;}
   }
  else if(a<c&&c<=5) {
       if(a<c){
        return 3; }
   }
   else if (c>5){
       if(c>5)
 return -1;}
    //return 0;
}
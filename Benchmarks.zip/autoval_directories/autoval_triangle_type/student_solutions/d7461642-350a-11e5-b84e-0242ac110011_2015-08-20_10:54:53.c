/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{//Program to determine type of triengle.
    int a,b,c;//sides of triangle.

scanf("%d%d%d",&a,&b,&c);//To enter length of sides of triengle.

if (a*a+b*b==c*c||a*a+c*c==b*b||b*b+c*c==a*a)
{
    return 1;//Pythagyouras theorem.
    
}

if (a*a+b*b>c*c&&a*a+c*c>b*b&&b*b+c*c>a*a)//cosine is positive in it.
{
    return 2;
    
}

if (a+b<=c||a+c<=b||b+c<=a)
{
    return -1;//no such triangle is there.
    
}

if ((a*a+b*b<c*c||a*a+c*c<b*b||b*b+c*c<a*a)&&(a+b>c&&a+c>b&&b+c>a))
{
    return 3;//cosine is negative.
    
}

    //return 0;
}
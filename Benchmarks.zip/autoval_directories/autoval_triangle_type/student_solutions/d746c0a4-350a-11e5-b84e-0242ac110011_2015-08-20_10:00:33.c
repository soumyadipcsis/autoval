/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c ;/* Enter the sides of a Triangle */
    int A,B,C ; 
    
    scanf("%d %d %d", &a, &b, &c);
    
     A=((b*b)+(c*c)-(a*a)); 
     B=((a*a)+(c*c)-(b*b)); 
     C=((a*a)+(b*b)-(c*c)); 
        
        if(((a+b<=c) || (a+c<=b) || (b+c<=a)) || (a<=0 || b<=0 || c<=0))
            {
                return -1;
            }
        
        else
            {
                if(A<0 || B<0 || C<0)
                    {
                        return 3;
                    }
                else
                    {
                        if(A==0 || B==0 || C==0)
                            {
                                return 1;
                            }
                        else
                            {
                                return 2;
                            }
                    }
            }
    //return 0;
}
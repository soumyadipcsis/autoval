/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    int x=a*a;
    int y=b*b;
    int z=c*c;
    int cosa=(y+z-x)/2*b*c;
    int cosb=(x+z-y)/2*a*c;
    int cosc=(y+x-z)/2*b*a;
    if((x==y+z)||(y==x+z)||(z==x+y))
        {
            return 1;
        }
  if(((a+b>c)&&(b+c>a)&&(a+c>b))&&(cosa<0 || cosb<0 || cosc<0))    
        {
            return 3;       
        }
    if(cosa>0 && cosb>0 && cosc>0)    
        {
            return 2;       
        }    
     if((a+b<=c)||(b+c<=a)||(a+c<=b))
        {
            return -1;
            
        }
    //return 0;
}
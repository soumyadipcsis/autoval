/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a; int b; int c;
    scanf("%d%d%d",&a,&b,&c); // input a,b,c
    if ((a+b)>c) { // sum of two side should be greater than third
    if ((a*a+b*b)<c*c) {      // triangle must be obtuse
        return 3;
    } else {   
    if ((a*a+b*b)==c*c) {  // triangle must be right angled
        return 1;
    } else {
    if ((a*a+b*b)>c*c) {  // triangle must be acute
        return 2;
    } else {
    } 
    }
    }
    } else {
        return -1; // no such triangle is possible
    }
    //return 0;
}
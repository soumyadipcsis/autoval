/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    int l,m,n;
    l=a*a+b*b;  // will be used for checking the type of triangle
    m=b*b+c*c;
    n=a*a+c*c;
    if(a<0||b<0||c<0) //Side cant be negative
    return -1;
    else{
    if ((a+b>c)&&(a+c>b)&&(b+c>a)) //Check for valid traingle
    {   if((l==c*c)||(m==a*a)||(n==b*b))
        return 1;
        else if(((l>c*c) + (m>a*a) + (n>b*b))==2)
        return 3;
        else
        return 2;
    }
    else
    return -1;
    }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
/*program to determine if the triangle is acute, right or obtuse. You should print "Invalid Triangle" if the side combinations do not correspond to a valid triangle.*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;
int student_solution(int input_a, int input_b, int input_c)
{
  int a,b,c;
   scanf("%d %d %d",&a,&b,&c);//a,b,c are sides of triangle
   if((a<b+c)&&(b<a+c)&&(c<a+b))//condition for triangle to exist
   {
   if((a*a==b*b+c*c)||(b*b==a*a+c*c)||(c*c==a*a+b*b))
   {
       return 1;
   }
       if((a*a>b*b+c*c)||(b*b>a*a+c*c)||(c*c>a*a+b*b))
   {
       return 3;
   }
   if((a*a<b*b+c*c)&&(b*b<a*a+c*c)&&(c*c<a*a+b*b))
   {
       return 2;
   }
   }
   if((a>b+c)||(b>a+c)||(c>a+b))//condition for triangle to be invalid
   {
       return -1;
   }
    //return 0;
}
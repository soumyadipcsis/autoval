/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int s1,s2,s3;                           //Three sides of a triangle
    scanf("%d%d%d",&s1,&s2,&s3);
    
    if( ((s1+s2)<=s3) || ((s2+s3)<=s1) || ((s3+s1)<=s2) )//invalid case
    {                                                    
         return -1;
    }
    else                                         //if triangle is valid
    {
        if( (((s1*s1)+(s2*s2))>(s3*s3)) && (((s2*s2)+(s3*s3))>(s1*s1))         && (((s3*s3)+(s1*s1))>(s2*s2)) )        //checking acute angled
        {
            return 2;
        }
        else
        if( (((s1*s1)+(s2*s2))==(s3*s3)) || (((s2*s2)+(s3*s3))==(s1*s1          )) || (((s3*s3)+(s1*s1))==(s2*s2)) )   //checking right angled
        {
            return 1;
        }
        else                //it is obtuse if none of the cases matches
        {
            return 3;
        }
    }
    //return 0;
}
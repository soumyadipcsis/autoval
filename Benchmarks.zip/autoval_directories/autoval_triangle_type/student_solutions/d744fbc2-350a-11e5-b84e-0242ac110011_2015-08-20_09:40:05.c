/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c; /* a,b,c are sides of triangle */
    scanf("%d %d %d",&a,&b,&c);
    if
    ((a+b<=c)||(a+c<=b)||(b+c<=a)){
    return -1;    
    }else if /* Condition for acute triangle */
    (((a*a)<(c*c)+(b*b))&&((b*b)<(a*a)+(c*c))&&((c*c)<(a*a)+(b*b))){
    return 2;
    }else if /* Condition for right triangle */
    ((b*b)==(a*a)+(c*c)||((c*c)==(b*b)+(a*a))||((a*a)==(b*b)+(c*c))){
    return 1;
    }else {
    return 3;
    }
    //return 0;
}
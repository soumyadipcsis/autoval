/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include <stdio.h>

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c); /*input 3 integers*/
    int max,min,mid; /*variables for maximum, middle and minimum*/
    
    if (a>b)              /*to find the maximum,*/
    {                     /*middle and minimum */
        if (a>c)          /*out of a, b and c*/
        {
            max=a;
            if (b>c)
            {
                mid=b;
                min=c;
            }
            else
            {
                mid=c;
                min=b;
            }
        }
        else
        {
            max=c;
            mid=a;
            min=b;
        }
    }
    
    else
    {
        if(b>c)
        {
            max=b;
            if (a>c)
            {
                mid=a;
                min=c;
            }
            else
            {
                mid=c;
                min=a;
            }
        }
        else
        {
            max=c;
            mid=b;
            min=a;
        }
    }
    
    int mx=max*max;  //Square of maximum
    int md=mid*mid;  //Square of middle
    int mn=min*min;  //Square of minimum
    
    if ((mid+min)>max) /*To check whether Triangle exists or not*/
    {
        if(mx==(md+mn))     /*Condition for Right Triangle*/
        {
            return 1;
        }
        else
        {
            if (mx<(md+mn)) /*Condition for Acute Triangle*/
            {
                return 2;
            }
            else            /*Else For Obtuse Triangle*/
            {
                return 3;
            }
        }
    }
    else   /*Else Invalid Triangle*/
    {
        return -1;
    }
    
    //return 0;
}
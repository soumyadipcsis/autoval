/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;/*SIDES OF TRIANGLE*/
    scanf("%d %d %d",&a,&b,&c);
    if((a+b)>c && (a+c)>b && (b+c)>a)/*CONDITION FOR TRIANGLE'S EXISTENCE*/
    {if((a*a == (b*b)+(c*c))||(b*b == (a*a)+(c*c))||(c*c == (b*b)+(a*a)))/*CONDITION FOR RIGHT ANGLE TRIANGLE*/
    return 1;
    else
    {if((a*a > (b*b)+(c*c))||(b*b > (a*a)+(c*c))||(c*c > (b*b)+(a*a)))/*CONDITION FOR OBTUCE ANGLE TRIANGLE*/
    return 3;
    else/*OTHERWISE IT IS ACUTE ANGLE TRIANGLE*/
    return 2;}
    }
    else 
    return -1;/*IT IS NOT A TRIANGLE*/
    //return 0;
}
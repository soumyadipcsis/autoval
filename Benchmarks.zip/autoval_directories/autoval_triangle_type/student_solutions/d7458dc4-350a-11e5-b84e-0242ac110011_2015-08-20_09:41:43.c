/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
 int a;/*define 3 integers*/
 int b;
 int c;
 scanf("%d %d %d",&a,&b,&c);/*input from user*/
 if (a+b>c && b+c>a && a+c>b)/*cond for triangle to be valid*/
 {if (a*a + b*b == c*c || b*b + c*c == a*a || a*a + c*c == b*b)/*condition for right triangle*/
 return 1;
 else
 {if (a*a + b*b < c*c || a*a + c*c < b*b || b*b + c*c < a*a)/*condition for obtuse triangle*/
 return 3;
 else 
 return 2;
 }
 }
 else 
 return -1;
 
    //return 0;
}
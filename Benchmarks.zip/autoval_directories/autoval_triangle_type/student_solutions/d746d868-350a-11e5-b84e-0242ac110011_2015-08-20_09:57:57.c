/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;
          /*print type of triangle*/
int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;                    /*sides of triangle*/
    scanf("%d%d%d",&a,&b,&c);
    if((a<b+c)&&(b<c+a)&&(c<a+b)){
        if((a>=b)&&(a>=c)){
            if((a*a)<(b*b)+(c*c)){
                return 2;
            }
            if((a*a)==(b*b)+(c*c)){
                return 1;
            }
            if((a*a)>(b*b)+(c*c)){
                return 3;
            }
        }
        if((b>=a)&&(b>=c)){
            if((b*b)<(a*a)+(c*c)){
                return 2;
            }
            if((b*b)==(a*a)+(c*c)){
                return 1;
            }
            if((b*b)>(a*a)+(c*c)){
                return 3;
            }
        }
        if((c>=a)&&(c>=b)){
            if((c*c)<(a*a)+(b*b)){
                return 2;
            }
                if((c*c)==(a*a)+(b*b)){
                    return 1;
            }
            if((c*c)>(a*a)+(b*b)){
                return 3;
            }
        }
    }else{
        return -1;
    }    
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
     int a,b,c;  //defining side length
     scanf("%d %d %d",&a,&b,&c);  //input side length
     
     if
     ((a+b>c)&&(b+c>a)&&(c+a>b)) //condition for triangle formation
     {
     
        if
        ((a*a+b*b==c*c)||(b*b+c*c==a*a)||(c*c+a*a==b*b)) //condition for right angled triangle
        {
                 return 1; //print right angled triangle
        }
        
        else if 
        ((a*a+b*b>c*c)&&(b*b+c*c>a*a)&&(c*c+b*b>a*a)) //neccessary conition for acute triangle
        {
                 return 2; //print result
        }
        
        else if
        ((a*a+b*b<c*c)||(b*b+c*c<a*a)||(c*c+a*a<b*b)) //neccessary condition for obtuse triangle
        {
                 return 3; //print the result
        }
     }
     
     else {
         return -1; //when no triangle formed
     }
     
     // Fill this area with your code.
    //return 0;
}
/*compile-errors:e156_271815.c:19:25: warning: '&&' within '||' [-Wlogical-op-parentheses]
    else if((c>=a&&c>=b)&&(c*c>a*a+b*b)||(a>=b&&a>=c)&&
            ~~~~~~~~~~~~^~~~~~~~~~~~~~~~~
e156_271815.c:19:25: note: place parentheses around the '&&' expression to silence this warning
    else if((c>=a&&c>=b)&&(c*c>a*a+b*b)||(a>=b&&a>=c)&&
                        ^
            (                          )
e156_271815.c:19:54: warning: '&&' within '||' [-Wlogical-op-parentheses]
    else if((c>=a&&c>=b)&&(c*c>a*a+b*b)||(a>=b&&a>=c)&&
                                       ~~~~~~~~~~~~~~^~
e156_271815.c:19:54: note: place parentheses around the '&&' expression to silence this warning
    else if((c>=a&&c>=b)&&(c*c>a*a+b*b)||(a>=b&&a>=c)&&
                                                     ^
e156_271815.c:20:32: warning: '&&' within '||' [-Wlogical-op-parentheses]
    (a*a>b*b+c*c)||(b>=a&&b>=c)&&(b*b>a*a+c*c))
                 ~~~~~~~~~~~~~~^~~~~~~~~~~~~~~
e156_271815.c:20:32: note: place parentheses around the '&&' expression to silence this warning
    (a*a>b*b+c*c)||(b>=a&&b>=c)&&(b*b>a*a+c*c))
                               ^
                   (                          )
3 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a;
    int b;
    int c;                        //Declaring variables
    scanf("%d %d %d",&a,&b,&c);   //Taking input
    
    if(a+b<= c||b+c<= a||a+c<= b) //Using if-else
        {
            return -1;
        }                         //Checking if invalid triangle
    else if(a*a+b*b==c*c||b*b+c*c==a*a||a*a+c*c==b*b)
        {
            return 1;
        }                        //Checking if right triangle

    else if((c>=a&&c>=b)&&(c*c>a*a+b*b)||(a>=b&&a>=c)&&
    (a*a>b*b+c*c)||(b>=a&&b>=c)&&(b*b>a*a+c*c))
        {
            return 3;
        }                       //Checking if obtuse triangle
    else
        { 
            return 2;
        }       //if no above case satisfies then acute triangle
   
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
# include <stdio.h>
 int student_solution(int input_a, int input_b, int input_c) {
     int a,b,c;
     scanf("%d",&a);   //taking 
     scanf("%d",&b);   //values of
     scanf("%d",&c);   //3 sides
     if((a||b)<c) {    //largest side=c
                if(c>a+b){return -1;}
             if((a+b>c)&&(b+c>a)&&(a+c>b)){
                    if(c*c>a*a+b*b){return 3;}
                    if(c*c<a*a+b*b){return 2;}
                   if(c*c==a*a+b*b){return 1;}}
     }
         
     //return 0;
 }
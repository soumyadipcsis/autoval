/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
int a,b,c;//a,b,c are sides of triangle
scanf("%d%d%d",&a,&b,&c);
if((a*a)+(b*b)==(c*c)||(a*a)+(c*c)==(b*b)||(c*c)+(b*b)==(a*a))
    return 1;//right triangle satisfies pythagorus theorum
else if (a+b<c||b+c<a||a+c<b)
    return -1;//any triangle cannot have two side less than third side
else if (((a*a)+(b*b)<(c*c))||((a*a)+(c*c)<(b*b))||((a*a)>(b*b)+(c*c)))
    return 3;//obtuse triangle has one angle>90
else if(((a*a)+(b*b)>(c*c)||(b*b)+(c*c)>(a*a)||(a*a)+(c*c)>(b*b)))
    return 2;
    // Fill this area with your code.
    //return 0;
}
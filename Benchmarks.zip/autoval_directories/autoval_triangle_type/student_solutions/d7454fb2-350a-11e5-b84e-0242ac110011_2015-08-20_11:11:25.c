/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
 int a,b,c; 
 scanf("%d %d %d",&a,&b,&c); 
 if ((a+b)>c && (b+c)>a && (c+a)>b) { // checking condition for triangle
     if (((a*a+b*b)>c*c) && ((a*a+c*c)>b*b) && ((c*c+b*b)>a*a)){ // condition for  acute triangle
         return 2;} 
     else if (((a*a+b*b)==c*c) || ((a*a+c*c)==b*b) || ((c*c+b*b)==a*a))       { // condition for right triangle
         return 1;} 
     else {return 3;} 
 }
 else {return -1;} // result if condition for triangle fails
    //return 0;
}
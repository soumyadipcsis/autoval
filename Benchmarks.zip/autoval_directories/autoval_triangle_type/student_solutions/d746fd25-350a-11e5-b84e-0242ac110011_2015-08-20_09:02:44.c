/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;/*to find out wheather a triangle is acute,obtuse,right or invalid triangle*/
int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;/*three sides of triangle*/
    scanf("%d%d%d",&a,&b,&c);
     if(a+b<c){return -1;}
     else{
    if((c*c)==((a*a)+(b*b))){return 1;}/*condition for right triangle*/
    if((c*c)<((a*a)+(b*b))){return 2;}/*condition for acute triangle*/
    if((c*c)>((a*a)+(b*b))){return 3;}/*condition for obtuse triangle*/
     }
    //return 0;
}
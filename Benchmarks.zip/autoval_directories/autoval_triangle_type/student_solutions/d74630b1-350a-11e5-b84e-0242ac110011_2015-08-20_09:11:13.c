/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;


int student_solution(int input_a, int input_b, int input_c)
{
int a;
int b;
int c;
scanf("%d %d %d",&a,&b,&c);
if((a+b>c)&&(b+c>a)&&(a+c>b)){/*checking validity of given sides*/
if(((a*a)==(b*b)+(c*c))||((b*b)==(a*a)+(c*c))||((c*c)==(a*a)+(b*b))) {
    return 1;/*case 1 of being right triangle*/ 
}
else if(((a*a)>(b*b)+(c*c))||((b*b)>(c*c)+(a*a))||((c*c)>(b*b)+(a*a))) {
    return 3;/*case for triangle to be obtuse should                                be checked before acuta*/
} 
else if(((a*a)<(b*b)+(c*c))||((b*b)<(c*c)+(a*a))||((c*c)<(b*b)+(a*a))) {
    return 2;/*last case for acute triangle*/
}}
else{/*if the side are not valid*/
    return -1;
}
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
int a,b,c;
scanf("%d%d%d",&a,&b,&c);/*Input integers*/

if((a+b>c)&&(b+c>a)&&(c+a>b))
{
    if((a*a+b*b>c*c)&&(b*b+c*c>a*a)&&(c*c+a*a>b*b))/*Condition for acute*/
    
    {
        return 2;
        
    }
    if((a*a+b*b<c*c)||(b*b+c*c<a*a)||(c*c+a*a<b*b))/*Condition for obtuse*/
    {
        return 3;
    }
    
    if ((a*a+b*b==c*c)||(b*b+c*c==a*a)||(c*c+a*a==b*b))
    {
        return 1;/*Right Ttiangle*/
        
    }
}
     else{
      return -1;}/*Invalid Triangle*/
    //return 0;
}
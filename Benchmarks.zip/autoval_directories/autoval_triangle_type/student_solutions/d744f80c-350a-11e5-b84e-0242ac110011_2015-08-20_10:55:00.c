/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c){
    int a,b,c,x,y,z;
     scanf("%d%d%d",&x,&y,&z);
     
    if(x>y&&x>z)
     {
       c=x,b=y,a=z;
     }
   else
     {
       if(y>z)
       {
           c=y,b=x,a=z;
       }
       else
       {
           c=z,a=x,b=y;
       }
     }
    if(a+b<c)
     {
      return -1;
     }
    else
     { 
        if((c*c)==(a*a+b*b))
        {
        return 1;
        }
        else
        {
          if((c*c)<((a*a)+(b*b)))
            {
              return 2;
            }
          else
              {
                if((c*c)>((a*a)+(b*b)))
                {
                  return 3; 
                }
               }
        }       
    //return 0;
    }}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;
/*program developed by someshwar jain to determine whether triangle is acute or obtuse or right angled*/
int student_solution(int input_a, int input_b, int input_c){
    int a,b,c;                   /*a,b,c are the sides of triangle*/
    scanf("%d%d%d",&a,&b,&c);   /*to give values of a,b&c*/
    if((a+b<=c)||(a+c<=b)||(b+c<=a)||(a<=0)||(b<=0)||(c<=0)){
        /*condition for triangle to be valid*/
        return -1;
    }
    else if(((a*a)+(b*b)>(c*c))&&
    ((a*a)+(c*c)>(b*b))&&
    ((c*c)+(b*b)>(a*a)))
    /*condition for acute triangle*/ 
    {
        return 2;
    }
    else if(((a*a)+(b*b)==(c*c))||
    ((a*a)+(c*c)==(b*b))||
    ((b*b)+(c*c)==(a*a)))
    {
        /*condition for right triangle(pythagoras theorm)*/
        return 1;
    }
    else if(((a*a)+(b*b)<(c*c))||
    ((a*a)+(c*c)<(b*b))||
    (b*b)+(c*c)<(a*a))
    {
        /*condition for obtuse triangle*/
        return 3;     
    }
    //return 0;
}
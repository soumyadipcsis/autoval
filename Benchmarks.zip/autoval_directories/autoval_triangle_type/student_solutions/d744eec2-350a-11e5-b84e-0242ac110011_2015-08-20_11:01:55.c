/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;
int student_solution(int input_a, int input_b, int input_c)
  { 
    int a;
    int b;
    int c;
    int max;// 'max' is introduced for storing the largest value 
    scanf("%d%d%d",&a,&b,&c);//input from user
    //algorithm for finding maximum value
    if  (a <= b)
        { if (b >= c)
            { 
                max =b;
            } 
          else 
            { 
                max=c;
            } 
          
        } 
    else 
        { if (a <= c) 
            {
            max=a;
            } 
          else 
            {
             max=c;
            }
        } 
        
    if ((a+b+c-(2*max))<=0)//sum of two sides must be greater than                                 third side for a valid triangle
        {
        return -1;
        } 
    else
    if ((a+b+c-(2*max))>=0) 
        {
            if ((a*a)+(b*b)+(c*c)==(2*max*max))// cosine of largest                                                      angle is zero 
            {
                return 1;
            }   else
            if((a*a)+(b*b)+(c*c)>=(2*max*max)) //cosine of largest                                                     angle is greater than 0
            {
                return 2;
            }   else
            if((a*a)+(b*b)+(c*c)<=(2*max*max))//cosine of largest                                                     angle is less than 0
            {
                return 3;
            }
        }

    //return 0;
}
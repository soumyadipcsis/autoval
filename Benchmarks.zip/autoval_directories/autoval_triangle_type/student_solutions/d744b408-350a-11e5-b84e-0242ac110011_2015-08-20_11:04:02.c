/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    int d=0;
    scanf("%d %d %d",&a,&b,&c);
    if (a<b||a<c)
    {
       if(b>=c)
        {
            d=a;
            a=b;
            b=d;
                            //finding max and swapping
        }
        else if(c>=b)
        {
            d=a;
            a=c;
            c=d;
        }
    }
    
    if ((b+c)<=a)               //condition check
    return -1;
    else
    
    {
    if((c*c+b*b)==a*a)
    return 1;   //right triangle
    
    else if((c*c+b*b)>a*a)
    return 2;   //acute traingle
    
    else if((c*c+b*b)<a*a)
    return 3;  //obtuse triangle
    
    }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    if(a+b>c && b+c>a && a+c>b)/*required condition for a triangle*/
    {
        if(a*a+b*b==c*c||b*b+c*c==a*a||c*c+a*a==b*b)/*required condition for a right tiangle*/
   {
    return 1;
    }
    else if(a*a+b*b>c*c&&b*b+c*c>a*a&&a*a+c*c>b*b)/*condition for a acute angled triangle*/
    {
        return 2;
    }
      
    else if(a*a+b*b-c*c<0||b*b+c*c-a*a<0||c*c+a*a-b*b<0) 
   { return 3;}}
    
    else
    {return -1;}

    //return 0;}

}

/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c; //given sides of the triangle
    scanf("%d%d%d",&a,&b,&c);
    if(a+b<=c||b+c<=a||c+a<=b)
    //sum of any two sides in a triangle should be greater than third       side
    {
    return -1;
    }
    else if(a*a+b*b==c*c||b*b+c*c==a*a||c*c+a*a==b*b)
    //sum of squares of two sides is equal to square of third side in a     right angled triangle
    {return 1;
    }
    else if(a*a+b*b<c*c||b*b+c*c<a*a||c*c+a*a<b*b)
    //cos(angle)=((a*a+b*b-c*c)/(2*a*b))<0 denotes that an angle is        greater than 90 degrees
    {
    return 3;
    }
    else if(a*a+b*b>c*c&&b*b+c*c>a*a&&c*c+a*a>b*b)
    //cos(angle)=((a*a+b*b-c*c)/(2*a*b))>0 denotes that an angle is        less than 90 degrees
    {
    return 2;
    }

//return 0;
}
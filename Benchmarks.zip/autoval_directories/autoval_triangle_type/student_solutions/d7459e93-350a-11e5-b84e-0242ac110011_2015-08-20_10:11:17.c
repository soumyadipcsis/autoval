/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int s1, s2, s3, x, y, a, b, c; //s1, s2, s3 are sides of a triangle
    scanf("%d %d %d", &s1, &s2, &s3);
   
    /*a, b, c tell whether the angle is acute or obtuse(Cosine rule, x checks how many angles are right angled, y checks the necessary condition for being a triangle*/
    a=(s1*s1)+(s2*s2)-(s3*s3);   
    b=(s3*s3)+(s1*s1)-(s2*s2);
    c=(s3*s3)+(s2*s2)-(s1*s1);
    x=(a==0)+(b==0)+(c==0);
    y=(s1+s2>s3)+(s2+s3>s1)+(s1+s3>s2);
    
    switch((a>0)+(b>0)+(c>0)){
        case 3: return 2; //Sufficient Condition
        break;
        case 2: if(x==1)//not sufficient condition need to check validity
                return 1; //only 1 angle is 90 deg
                else if(y==3) //checks validity of triangle 
                return 3;
                else
                return -1;
        break;
        default: return -1;
    }
    //return 0;
}
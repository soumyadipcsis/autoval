/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
int a,b,c;

scanf("%d%d%d",&a,&b,&c);

if( (a+b < c) || (b+c < c) || (a+c < b) )
           return -1;
           
           
else if((c*c == a*a + b*b) || (a*a == b*b + c*c) || (b*b == a*a + c*c))
           return 1;
         
else if( (a>b && a>c) && (a*a < b*b + c*c) )
           return 2;
else if( (b>c && b>a) && (b*b < a*a + c*c) )
           return 2;
else if( (c>a && c>a) && (c*c < a*a + b*b) )
           return 2;
           
else if( (c>a && c>b) && (c*c > a*a + b*b) )
           return 3;
else if( (a>b && a>c) && (a*a > b*b + c*c) )
           return 3;
else {
    if((b>a && b>c) && (b*b > a*a + c*c))
           return 3;
}
//return 0;
}
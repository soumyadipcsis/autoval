/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{// This problem is solved by using cosine rule. The number of cases is humongously large so I have taken cyclic repetitive cases together which require no more than a copy paste command. Kindly dont go through the trouble of reading them all as they are all mostly copy paste work. 
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    //INVALID TRIANGLE CASES
    if (((a+b<=c)||(b+c<=a))||(c+a<=b)){// triangle inequality
        return -1;
        
    }
    else{// SCALENE TRIANGLE CASES
        if ((a>b)&&(b>c)){// taking this case we can use the cosine formulae as shown below.
           if (((b*b)+(c*c)-(a*a))>0){
               return 2;
           }    
        
            if (((b*b)+(c*c)-(a*a))<0){
                return 3;
                
            } 
            if (((b*b)+(c*c)-(a*a))==0){
                return 1;}
            
        }
         if ((a>c)&&(c>b)){// cyclic repetition
           if (((b*b)+(c*c)-(a*a))>0){
               return 2;
           }    
        
            if (((b*b)+(c*c)-(a*a))<0){
                return 3;
                
            } 
            if (((b*b)+(c*c)-(a*a))==0){
                return 1;}
            }    
        if ((b>a)&&(a>c)){// cyclic repetition
           if (((a*a)+(c*c)-(b*b))>0){
               return 2;
           }    
        
            if (((a*a)+(c*c)-(b*b))<0){
                return 3;
                
            } 
            if (((a*a)+(c*c)-(b*b))==0){
                return 1;}
            
        }
        if ((b>c)&&(c>a)){// cyclic repetition
           if (((a*a)+(c*c)-(b*b))>0){
               return 2;
           }    
        
            if (((a*a)+(c*c)-(b*b))<0){
                return 3;
                
            } 
            if (((a*a)+(c*c)-(b*b))==0){
                return 1;}
            
        }
        if ((c>a)&&(a>b)){//cyclic repetition
           if (((a*a)+(b*b)-(c*c))>0){
               return 2;
           }    
        
            if (((a*a)+(b*b)-(c*c))<0){
                return 3;
                
            } 
            if (((a*a)+(b*b)-(c*c))==0){
                return 1;}
            
        }
        if ((c>b)&&(b>a)){//cyclic repetition
           if (((a*a)+(b*b)-(c*c))>0){
               return 2;
           }    
        
            if (((a*a)+(b*b)-(c*c))<0){
                return 3;
                
            } 
            if (((a*a)+(b*b)-(c*c))==0){
                return 1;}
            
        }
    // EQUILATERAL TRIANGLE CASE
        if ((a==b)&&(b==c)){
            return 2;
        }
    // ISOCELES TRIANGLE CASES
        if (((a==b)&&(b>c))||((b==c)&&(c>a))||((c==a)&&(a>b))){// direct result of cosine rule
            return 2;
        }
    
        if ((a==b)&&(c>b)){
            if (((a*a)+(b*b)-(c*c))>0){// case considered using cosine rule.
               return 2;
           }    
        
            if (((a*a)+(b*b)-(c*c))<0){
                return 3;
                
            } 
            if (((a*a)+(b*b)-(c*c))==0){
                return 1;}
            
        }
        if ((c==b)&&(a>c)){// cyclic repetition
            if (((c*c)+(b*b)-(a*a))>0){
               return 2;
           }    
        
            if (((c*c)+(b*b)-(a*a))<0){
                return 3;
                
            } 
            if (((c*c)+(b*b)-(a*a))==0){
                return 1;}
            
        }
    
        if ((a==c)&&(b>c)){//cyclic repetition
            if (((a*a)+(c*c)-(b*b))>0){
               return 2;
           }    
        
            if (((a*a)+(c*c)-(b*b))<0){
                return 3;
                
            } 
            if (((a*a)+(c*c)-(b*b))==0){
                return 1;}
            
        }
            
    }
    
    //return 0;
        }
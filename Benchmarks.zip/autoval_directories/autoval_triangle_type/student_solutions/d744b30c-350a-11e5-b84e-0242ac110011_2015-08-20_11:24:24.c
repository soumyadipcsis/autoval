/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int p,q,r;
    scanf("%d %d %d",&p,&q,&r);
    if(p+q<=r||q+r<=p||r+p<=q)
    
    return -1;
    
   else
   {
      if((p*p==q*q+r*r)||(q*q==r*r+p*p)||(r*r==p*p+q*q))
        return 1;
       
    else
   { if((r*r>p*p+q*q)||(p*p>q*q+r*r)||(q*q>r*r+p*p))
        return 3;
   else 
   return 2;
   }
   }
  //return 0;
}
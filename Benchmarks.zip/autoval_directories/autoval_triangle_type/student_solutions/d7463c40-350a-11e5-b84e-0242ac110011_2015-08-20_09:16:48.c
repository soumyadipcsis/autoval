/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
 int a,b,c;
 scanf ("%d%d%d",&a,&b,&c);//taking input of 3 integers
 if ((a+b)>c&&(a+c)>b&&(b+c)>a)//checking the condition of validity of triangle
 {
     if ((a*a)+(b*b)==(c*c)||(a*a)+(c*c)==(b*b)||(b*b)+(c*c)==(a*a))
     {
         return 1;//since the order is not given we have to check all the 3 cases
     }
     else if((a*a)+(b*b)<(c*c)||(a*a)+(c*c)<(b*b)||(b*b)+(c*c)<(a*a))
     {
         return 3;//condition of obtuse triangle
     }
     else if((a*a)+(b*b)>(c*c)||(a*a)+(c*c)>(b*b)||(b*b)+(c*c)>(a*a))
     {
         return 2;//condn. of acute triangle
     }
 }
 else
 return -1;//not a valid triangle
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
int x,y,z;
scanf("%d%d%d",&x,&y,&z);
 if((z>x+y)||(x>y+z)||(y>x+z)){
 return -1;
 }
 else if((y*y==x*x+z*z)||(x*x==y*y+z*z)||(z*z==x*x+y*y)){
   return 1;
 }
 else if((y*y<x*x+z*z)||(x*x<y*y+z*z)||(z*z<x*x+y*y)){
     return 2;
 }
 else if((y*y>x*x+z*z)||(x*x>y*y+z*z)||(z*z>x*x+y*y)){
     return 3;
 
 }
 //return 0;
}
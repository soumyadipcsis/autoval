/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c,tmp;// tmp as temporary variable for swapping
    scanf("%d%d%d",&a,&b,&c);
    if(a>c)       // to check largest side 
    {
            tmp=c;// swapping
            c=a;
            a=tmp;
    }
    if(b>c)       // to check largest side
    {
        tmp=c;    // swapping
        c=b;
        b=tmp;
    }
    if((a+b>c)&&(b+c>a)&&(c+a>b)) // checking property of triangle
    {
            if(((a*a)+(b*b))==(c*c))// checking for right triangle
            return 1;
        else
            if(((a*a)+(b*b))<(c*c)) // checking for obtuse triangle
            return 3;
        else
            if(((a*a)+(b*b))>(c*c)) // checking for acute triangle
            return 2;
    }
    else
    return -1;// in case property is not satisfied
    //return 0;
}
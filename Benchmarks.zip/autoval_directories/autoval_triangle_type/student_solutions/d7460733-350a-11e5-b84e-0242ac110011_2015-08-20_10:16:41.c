/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

        /*Types of triangel*/
int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;


    scanf("%d %d %d",&a,&b,&c); 
    
    if((a*a)+(b*b)-(c*c)>(2*a*b) || (a*a)+(c*c)-(b*b)>(2*a*c) || (c*c)+(b*b)-(a     *a)>(2*b*c))
    {
         return -1;
    }     
    else
    
    
    if((a*a)+(b*b)==(c*c))
    {
         return 1;
    }     
    else
    
    
    if((a*a)+(b*b)-(c*c)>0)
    {
         return 2;
    } 
    else
    
    
     if((a*a)+(b*b)-(c*c)<0)
    {
         return 3;
    }     
    // Fill this area with your code.
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;
#include<math.h>

int student_solution(int input_a, int input_b, int input_c)
{    
          //a,b,c are sides of triangle
    int a,b,c,longside,smlside,midside,lg_sqr,sm_sqr,md_sqr;
    scanf("%d %d %d",&a,&b,&c);
          //sum of any two sides of triangle is greater than other side
          
    if(a+b>c&&b+c>a&&a+c>b) 
    {     //arranging sides in ascending order
        if(a>b)
        {
            if(a>c)
            {
                longside=a;
                if(b>c)
                {
                    smlside=c;
                    midside=b;
                }
                else
                {
                    smlside=b;
                    midside=c;
                }
            }
            else
            {
                longside=c;
                midside=a;
                smlside=b;
            }
        }
        else if(b>c)
        {
            longside=b;
            if(a>c)
            {
                midside=a;
                smlside=c;
            }
            else
            {
                midside=c;
                smlside=a;
            }
        }
        else
        {
            longside=c;
            midside=b;
            smlside=a;
        }
           //squaring the ordered sides by power func
        lg_sqr=pow(longside,2);
        sm_sqr=pow(smlside,2);
        md_sqr=pow(midside,2);
          //algorithm:if ae2+be2=ce2(rigth triangle by pythagoras thm)
          //          if ae2+be2> and <ce2(obtuse and acute triangle)
          
        if(lg_sqr==sm_sqr+md_sqr)
        {
            return 1;
        }
        else if(lg_sqr>sm_sqr+md_sqr)
        {
            return 3;
        }
        else
        {
            return 2;
        }
        
    }
    else
    {
        return -1;
    }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a;
    int b;
    int c;
    
    scanf("%d%d%d",&a,&b,&c);
    if(a+b>c && a+c>b && b+c>a)
    {
        if(a*a==b*b+c*c || b*b==a*a+c*c || c*c==a*a+b*b)
         {
         return 1;
         }
        else
         {
             if(a*a>b*b+c*c || b*b>a*a+c*c || c*c>a*a+b*b)
             {
              return 3;   
             }
             else
              return 2;
         }
         
              
    }
    else
     return -1;

    //return 0;
}

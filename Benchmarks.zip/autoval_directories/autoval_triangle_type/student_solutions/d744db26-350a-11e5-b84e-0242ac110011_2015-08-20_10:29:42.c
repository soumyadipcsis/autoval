/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;
/*program to check whether the triangle is acute,right,obtuse or invalid by using nested if else statements*/
int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);/*values to be entered by user*/
    if((a+b<=c)||(a+c<=b)||(b+c<=a))/*condition to check whether the triangle is valid or not,if it is invalid then print the below statement and if it is valid then go to the else part*/
    return -1;
    else
    {
    if((a*a==b*b+c*c)||(b*b==a*a+c*c)||(c*c==a*a+b*b))/*to check whether the triangle is right angle triangle or not*/
    return 1;
    else
    {
    if((a*a>b*b+c*c)||(b*b>a*a+c*c)||(c*c>a*a+b*b))/*to check whether the triangle is obtuse or acute*/
    return 3;
    else
    return 2;
    }
    }
    //return 0;
}
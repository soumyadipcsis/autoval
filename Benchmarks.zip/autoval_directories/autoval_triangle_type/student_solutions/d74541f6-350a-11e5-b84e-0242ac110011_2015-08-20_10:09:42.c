/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{ int a,b,c;//sides of a triangle
  scanf("%d %d %d", &a, &b, &c);
  if(a+b>c&&b+c>a&&a+c>b)//condition for three sides to form triangle
  {
      if(a*a+b*b>c*c&&b*b+c*c>a*a&&c*c+a*a>b*b)//condition for triangle to be acute triangle
      {
          return 2;
      }
    else if(a*a+b*b<c*c||a*a+c*c<b*b||b*b+c*c<a*a)//condition for triangle to be obtuse triangle
    {
          return 3;
     }
          else//(a*a+b*b=c*c||a*a+c*c=b*b||b*b+c*c=a*a) condition for triangle to be right triangle
          {
              return 1;
          }
          }
     else//(a+b<c&&b+c<a&&a+c<b) invalid conditin to be a triangle
     {
         return -1;
     } 
      
  
    // Fill this area with your code.
    //return 0;
}
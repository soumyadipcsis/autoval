/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    //sum of two sides in a triangle must greater than third side.
    if(a+b>c&&b+c>a&&a+c>b){
        if(c>a&&c>b){   //if C is the largest angle.
            if(c*c<a*a+b*b){
                return 2;
            }
            if(c*c>a*a+b*b){
                return 3;
            }
            if(c*c==a*a+b*b){
                return 1;
            }
        }    
        if(a>b&&a>c){   //If A is the largest angle.
            if(a*a<b*b+c*c){
                return 2;
            }
            if(a*a>b*b+c*c){
                return 3;
            }
            if(a*a==b*b+c*c){
                return 1;
            }
        }    
        if(b>a&&b>c){   //If B is the largest angle.
            if(b*b<a*a+c*c){
                return 2;
            }
            if(b*b>a*a+c*c){
                return 3;
            }
            if(b*b==a*a+c*c){
                return 1;
            }
        }
    }    
    else{
        return -1;
    }
        
        
    
    
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
int a,b,c;/*input variable*/
scanf("%d%d%d",&a,&b,&c);
if(a+b>c && b+c>a && c+a>b)/*triangle inequality*/
{
if( 
    ((a*a) + (b*b)== (c*c)) ||((b*b) + (c*c) == (a*a)) || ( (a*a) + (c*c)== (b*b))/* pythagoras theorem */
    )

{return 1;}
else if( 
    ((a*a) +(b*b)<( c*c)) ||(( b*b )+ (c*c) <( a*a)) || ((a*a) + (c*c)<(b*b))
    )
{return 3;}
else 
{return 2;}
}
else
{return -1;}
    //return 0;
}

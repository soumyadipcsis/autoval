/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c ;
    scanf("%d%d%d",&a,&b,&c);
    if (a+c<=b||a+b<=c||b+c<=a)//sum of two sides if less than or equal to third side then triangle is not possible
    {
        return -1;
    }
    else if (b*b==a*a+c*c||a*a==b*b+c*c||c*c==a*a+b*b)//pythagorean right triangle formula
    {
        return 1;
    }
    
    else if (b*b>a*a+c*c||a*a>b*b+c*c||c*c>a*a+b*b)//sum of  two sides if more than  third side then  triangle is obtuse
    {
        return 3;
    
    }
    else if (b*b<a*a+c*c||a*a<b*b+c*c||c*c<a*a+b*b)//sum of square of two sides if less than the square of third side then  triangle is acute
    {
        return 2;
        
    }
    //return 0;
    }
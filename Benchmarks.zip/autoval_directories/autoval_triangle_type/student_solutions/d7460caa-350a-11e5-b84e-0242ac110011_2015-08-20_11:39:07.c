/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
   /*                   PROBLEM
   You would be given three integers as input which corresponds to the three sides of a triangle. Write a program to determine if the triangle is acute, right or obtuse. You should print "Invalid Triangle" if the side combinations do not correspond to a valid triangle.     */
   
    int a,b,c,tmp;              //declaring variables(tmp for swapping)
    scanf("%d %d %d",&a,&b,&c); // taking the input
   
                /*   taking maximum of a b & c  in a*/   
   
    if (a<b)                    //  checking b/w a & b
    {                           //   swapping if a is not greater
       tmp=a;                   //  swapping  
       a=b;                     //   variables
       b=tmp;                   //    a  &  b 
    }
    if (a<c)                    //  checking b/w a & c
    {                           //   swapping if a is not greater
       tmp=a;                   //  swapping  
       a=c;                     //   variables
       c=tmp;                   //    a  &  c 
    }
                /*  Matching conditions and OUTPUT  */
    
    if (a >= (b + c))           // condition of invalid triangle
    {
        return -1;        // printing output
    }
    else if ( (a*a) > ( (b*b) + (c*c) ) )  // cond. of obtuse triangle
    {
        return 3;         // printing output
    }
    else if ( (a*a) < ( (b*b) + (c*c) )  ) // cond. of acute triangle
    {
        return 2;          // printing output
    }
    else                                   // otherwise right triangle
    {
        return 1;          // printing output
    }
    
    //return 0;                              // end of programme
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
int a,b,c;
scanf("%d %d %d",&a,&b,&c);/*inputing the sides of the triangles*/
    if(a>=b+c||b>=a+c||c>=a+b)
    /*checking if the sides form a triangle*/
           
           return -1;
    
    else if(c*c>a*a+b*b||b*b>a*a+c*c||a*a>b*b+c*c)
    /*checking if the triangle is obtuse*/
           
           return 3;
    
    else if(c*c==a*a+b*b||b*b==a*a+c*c||a*a==b*b+c*c)
    /*checking if the triangle is acute */

           return 1;
    else
    /*The only possiblity left is that triangle is acute angled*/      
           
           return 2;
//return 0;
}
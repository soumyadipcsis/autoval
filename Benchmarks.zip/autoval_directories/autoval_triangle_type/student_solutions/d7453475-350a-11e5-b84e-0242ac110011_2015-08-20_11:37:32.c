/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c) {
 int a,b,c;
 scanf("%d %d %d",&a,&b,&c);    //read inputs from the user.
 
 if ((a+b>c)&&(b+c>a)&&(a+c>b))
 
  //check if the triangle is valid using                                   'and' boolean expression. 
    { if ((a*a+b*b==c*c)||(b*b+c*c==a*a)||(a*a+c*c==b*b))
      {return 1;}
      if ((a*a+b*b>c*c)||(b*b+c*c>a*a)||(a*a+c*c>b*b))
      {return 3;}
      if ((a*a+b*b<c*c)||(b*b+c*c<a*a)||(a*a+c*c<b*b))
      return 2;
    }
    else {
        return -1;
    }
     
       
 //return 0;
 }
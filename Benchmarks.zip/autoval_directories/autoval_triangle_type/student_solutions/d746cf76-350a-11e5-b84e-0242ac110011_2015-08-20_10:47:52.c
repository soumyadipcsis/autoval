/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf ("%d %d %d",&a, &b, &c);
    if ((a>=b)&&(a>=c)){                 // a is the greatest side
        if (a>=(b+c))                    // triangle inequality false
        return -1;
        else if ((a*a)>((b*b)+(c*c)))
        return 3;
        else if ((a*a)==((b*b)+(c*c)))
        return 1;
        else return 2;
    }
     if ((b>=a)&&(b>=c)){                // b is the greatest side   
        if (b>=(a+c))
        return -1;
        else if ((b*b)>((a*a)+(c*c)))
        return 3;
        else if ((b*b)==((a*a)+(c*c)))
        return 1;
        else return 2;
    }
     if ((c>=b)&&(c>=a)){                // c is the greatest side    
        if (c>=(b+a))
        return -1;
        else if ((c*c)>((b*b)+(a*a)))
        return 3;
        else if ((c*c)==((b*b)+(a*a)))
        return 1;
        else return 2;
    }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;// variable for sides of triangle
    int check;// check whether triangle acute,obtuse or right angled
    int max; //variable to store maximum side of triangle
    
    scanf("%d%d%d",&a,&b,&c);//input sides of triangle
    
    
    if(((a+b>c)&&(b+c>a)&&(c+a>b))==0) //evaluate when sides of  
    {                                  // triangle are invalid
     
        return -1;
    }
    
    else    //evaluate when sides of triangle are valid
    {  
        
        max=a;  // code to check maximum side of triangle
        if(b>=a)
        { max=b;
          if(c>=b)
          max=c;
          
        }
        else
        { if(c>=a)
          max=c;
        }
        
        
// code to check whether triangle is acute,obtuse or right angled
// according to max side
          if(max==c)  
          { 
             check=b*b+a*a-c*c; 
             if(check>0)
             return 2;
             
             else if(check<0)
             return 3;
             
             else
             return 1;
          }
          else if(max==a)
          {
            check=b*b+c*c-a*a;
            if(check>0)
            return 2;
            else if(check<0)
            return 3;
            else
            return 1;
          }   
          else
          { 
            check=a*a+c*c-b*b;
            if(check>0)
            return 2;
            else if(check<0)
            return 3;
            else
            return 1;
           }
    
    }  
    //return 0;
}
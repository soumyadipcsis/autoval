/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c){
    
int a,b,c,d;
scanf("%d%d%d",&a,&b,&c);
if((a>b)&&(a>c)){/*checking wheather a is greatest or not*/
    d=(b*b+c*c)-(a*a);
    if((b+c)>a){/*checking wheather sides are satisfying triangle inequality or not*/
    if(d>0)
    return 2;
    else if(d==0)
    return 1;
    else return 3;
    }
    else return -1;
}
else if((b>a)&&b>c)
{
    d=(a*a+c*c)-b*b;
    if((a+c)>b)
    {
        if (d==0)
        return 1;
        else if (d>0)
        return 2;
        else return 3;
    }
    else return -1;
    }
    else
    {
    d=(b*b+a*a)-(c*c);
    if((a+b)>c)
{
    if(d==0) return 1;
    else if (d>0) return 2;
    else return 3;
}
else return -1;
}
    
    
    
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{ 
    int x,y,z; /* 3 sides of a triangle*/
int a,b,c;
 scanf("%d %d %d",&x,&y,&z);
 
 if (x<=y && y>=z) {a=x; b=y; c=z; }
 if (x<=z && z>=y) {a=x; b=z; c=y; }
 if (y<=x && x>=z) {a=y; b=x; c=z; }
   if (a+c>=b) 
   {
 if (a*a+c*c==b*b) {
     return 1;
 }
else if (a*a+c*c>=b*b) {
    return 2;
}
else if (a*a+c*c<=b*b) {
    return 3;
}
}
else if (a+c<=b) {
    return -1;
}

 
 //return 0;
}
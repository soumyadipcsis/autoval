/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;  //variables to store the lengths of 3 sides of triangle
    scanf("%d%d%d",&a,&b,&c);
    if((a+b<=c)||(a+c<=b)||(b+c<=a))  //Triangle inequality is violated
    {                               
        return -1; 
    }
    else
    {
        //------------------------------------------------------------
        //  storing the length of the largest side in variable c
        if(a>c)
        {
            int temp1; //temporary variable to swap the values of a & c
            temp1=a;
            a=c;
            c=temp1;
        }
        if(b>c)
        {
            int temp2; //temporary variable to swap the values of b & c
            temp2=b;
            b=c;
            c=temp2;
        }
        //c stores the value of the largest side
        //------------------------------------------------------------
        if((c*c)==((a*a)+(b*b)))        //condition for triangle to be                                         //right angled
        { 
            return 1;
        }
        else if((c*c)>((a*a)+(b*b)))      //condition for triangle to                                            //be obtuse angled
             {
                return 3;
             }    
             else if((c*c)<((a*a)+(b*b)))  //condition for triangle to                                            //be acute angled
                  {
                    return 2;
                  }
    }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c; //initialising the three integers
    scanf("%d%d%d",&a,&b,&c);
    if (a+b<=c || b+c<=a || a+c<=b || (a<=0 || b<=0 || c<=0)) //checking the condition for an invalid triangle
    {
        return -1;
    }
    else //nesting loops
    { 
        if ((((a*a)+(b*b)-(c*c))==0)
        || (((a*a)+(c*c)-(b*b))==0)
        || (((b*b)+(c*c)-(a*a))==0)) //conditions for a right angle triangle
        {
            return 1;
        }
        else{
            if ((((a*a)+(b*b)-(c*c))<0)
            || (((a*a)+(c*c)-(b*b))<0)
            || (((b*b)+(c*c)-(a*a))<0)) // conditions for an obtuse angle triangle
            {
                return 3;
            }
            else
            {
                return 2; //the only other optionl left, i.e. acute angle triangle
            }
        }
    }
    //return 0;
    }

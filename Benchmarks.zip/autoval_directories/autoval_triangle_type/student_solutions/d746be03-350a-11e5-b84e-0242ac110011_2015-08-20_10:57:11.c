/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;
int student_solution(int input_a, int input_b, int input_c)
{
 int a,b,c; // input three natural no.
 scanf("%d %d %d",&a,&b,&c);
 if(a+b>c && b+c>a && a+c>b)// condition for triangle
    { 
     if(c*c==a*a+b*b || a*a==b*b+c*c || b*b==a*a+c*c)
         return 1;//for right triangle
     else if(c*c>a*a+b*b || b*b>a*a+b*b || a*a>b*b+c*c)
        {
        return 3;// for obtuse triangle
        }
     else if(c*c<a*a+b*b || b*b<a*a+c*c || a*a<b*b+c*c)  
        {
        return 2;// for acute triangle
        }
    }
    else return -1;// triangle does not exist
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;//these are the input for sides of triangle
    scanf("%d%d%d",&a,&b,&c);//to scan input
    if(((a+b)<=c)||((b+c)<=a)||((c+a)<=b))/*the sum of any two sides of
    triangle must be greater than third*/
    return -1;
    if(((a+b)>c)&&((b+c)>a)&&((c+a)>b)){/*the sum of any two sides on a     triangle must be greater than third side*/
        if(((a*a+b*b)>c*c)&&((a*a+c*c)>b*b)&&((b*b+c*c)>a*a))/*formula     for finding nature of a triangle*/ /*acute       means all angles     must be less than 90 degree*/
        return 2;
        else if(((a*a+b*b)==c*c)||((a*a+c*c)==b*b)||((b*b+c*c)==a*a        ))/*right means one angle must equal to 90 degree*/
        return 1;
        else /*obtuse means on angle must be greater than 90 degree*/
        return 3;
    }
    //return 0;
}
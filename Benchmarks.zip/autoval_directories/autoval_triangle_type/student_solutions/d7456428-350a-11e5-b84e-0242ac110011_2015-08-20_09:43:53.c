/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{int a,b,c;
scanf("%d%d%d",&a,&b,&c);
if(((a+b)<=c)||((b+c)<=a)||((a+c)<=b))
   return -1;
else if(a<=0||b<=0||c<=0)
return -1;
else
   {if(a>=b && a>=c)/*checking for largest side*/
      {if(a*a==(b*b+c*c))
        return 1;
       else if(a*a>(b*b+c*c))
        return 3;
       else if(a*a<(b*b+c*c))
        return 2;}
    else if(b>=a && b>=c)
       {if(b*b==(a*a+c*c))
        return 1;
       else if(b*b>(a*a+c*c))
        return 3;
       else if(b*b<(a*a+c*c))
        return 2;}
    else    
        {if(c*c==(a*a+b*b))
        return 1;
       else if(c*c>(a*a+b*b))
        return 3;
       else if(c*c<(a*a+b*b))
        return 2;}}



    // Fill this area with your code.
    //return 0;
}

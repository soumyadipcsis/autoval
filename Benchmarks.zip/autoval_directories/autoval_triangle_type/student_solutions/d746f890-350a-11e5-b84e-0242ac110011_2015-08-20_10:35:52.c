/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;/*DECLARATION OF VARIABLES*/
    /* ENTERING SIDE FROM USER AS a,b,c*/ 
    scanf("%d%d%d",&a,&b,&c);
    /*DECLARING ANOTHER SET OF VARIABLES*/
    int s1,s2,s3;
    /* CODE TO ASSIGN s1 AS LARGEST SIDE ,s2 SECOND LARGEST AND S3         SMALLEST SIDE*/
    if(a>=b)
    {
       if(a>=c)
       {
           s1=a; 
           if(b>=c)
           {
               s2=b;
               s3=c;
           }
           else
           {
               s2=c;
               s3=b;
           }
       }
       else
       {
            s1=c;
            s2=a;
            s3=b;
       }
    }
    else
    {
        if(b>=c)
        {
            s1=b;
            if(a>=c)
            {
                s2=a;
                s3=c;
            }
            else
            {
                s2=c;
                s3=a;
            }
        }
        else
        {
            s1=c;
            s2=b;
            s3=a;
        }
    }
    /* 
    CHECKING IF GIVEN SET OF NUMBERS FORM TINGLE
    LARGEST SIDE SHOULD BE LESS THAN SUM OF OTHER TWO SIDES
    SMALLEST SIDE SHOULD BE GREATER THAN DIFFERENCE OF OTHER TWO
    */
    if(((s2+s3)>s1)&&((s1-s2)<s3))
    { 
      /*SUM = SUM OF SQUARE OF TWO SIDE - SQUARE LARGEST SIDE*/ 
      int sum= (s3*s3)+(s2*s2) -(s1*s1);
      if(sum==0)//RIGHT ANGLE
      return 1;
      else if(sum>0)//ACUTE
      return 2;
      else//OBTUSE
      return 3;
    }
    else
    {
      return -1;
    }
    //return 0;
}

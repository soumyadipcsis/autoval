/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{int a,b,c;/*let a,b,c be three sides of the triangle*/
 
 scanf("%d %d %d",&a,&b,&c);
 if((a+b>c)&&(b+c>a)&&(a+c>b))/*checking the triangle is valid or not*/  
 { if(((a*a+b*b)<c*c)||((c*c+b*b)<a*a)||((a*a+c*c)<b*b))
      return 3;/*condition for obtuse triangle*/
   else  
      {if(((a*a+b*b)==c*c)||((c*c+b*b)==a*a)||((a*a+c*c)==b*b))
         return 1;/*condition for right triangle*/
      else
        if(((a*a+b*b)>c*c)&&((c*c+b*b)>a*a)&&((a*a+c*c)>b*b))
          return 2;/*condition for acute triangle*/
     } 
 }
 
 else
   return -1;
 
 //return 0;
}
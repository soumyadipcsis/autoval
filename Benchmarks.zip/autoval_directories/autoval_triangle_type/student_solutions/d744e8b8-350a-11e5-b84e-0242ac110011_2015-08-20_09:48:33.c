/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{   
    int a,b,c;
    int p,q,r;
    scanf("%d %d %d",&a,&b,&c);  
    p=(a*a)+(b*b)-(c*c);        
    q=(b*b)+(c*c)-(a*a);   
    r=(a*a)+(c*c)-(b*b);
    if(((a+b)<=c)||((b+c)<=a)||((a+c)<=b))   //checking for valid                                                   // triangle
    {
        return -1;
    }
    else
    {
        if((p>0)&&(q>0)&&(r>0))             //cond for acute triangle
        {
            return 2;
        }
        else if((p==0)||(q==0)||(r==0))     //cond for right triangle
        {
            return 1;
        }
        else if((p<0)||(q<0)||(r<0))        //cond for obtuse triangle
        {
            return 3;
        }
       
    }
    //return 0;
}
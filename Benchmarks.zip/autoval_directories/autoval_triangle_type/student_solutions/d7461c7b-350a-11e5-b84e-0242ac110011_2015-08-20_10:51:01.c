/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{   
    int a,b,c;                  // a,b,c denotes sides of triangle
    scanf("%d%d%d",&a,&b,&c);
    
        // checking side corresponds to valid triangle
    
    if(((a+b)<=c)||((b+c)<=a)||((c+a)<=b))
        
        {   
            return -1;
        }
        
        //  checking type of triangle by pythagoras property
        
    else if(((a*a)==(b*b)+(c*c))||((b*b)==(c*c)+(a*a))||((c*c)==(a*a)+(b*b)))
        {  
            return 1;       
        }
        
        // acute angled triangle condition
        
    else if(((b*b)+(c*c)>(a*a))&&((a*a)+(b*b)>(c*c))&&((c*c)+(a*a)>(b*b)))
        {   
           return 2;
        }
        
        // obtuse angled triangle condition
        
    else if(((a*a)>(b*b)+(c*c))||((c*c)>(a*a)+(b*b))||((b*b)>(c*c)+(a*a)))
        {   
            return 3;
        }
    
    //return 0;
}
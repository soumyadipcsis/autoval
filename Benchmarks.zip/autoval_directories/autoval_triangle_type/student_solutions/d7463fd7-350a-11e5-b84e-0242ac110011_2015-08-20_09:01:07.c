/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    if (b*b+c*c>a*a && a*a+b*b>c*c && a*a+c*c>b*b){return 2;}
    else if (b*b+c*c==a*a || c*c+a*a==b*b || a*a+b*b==c*c)
    {return 1;}
    else if ((b*b+c*c<a*a || a*a+b*b<c*c || c*c+a*a<b*b)&&(b+c>a && a+b>c && c+a>b))
    {return 3;}
    if (b+c<a || c+a<b || a+b<c)
    {return -1;}
    //return 0;
}
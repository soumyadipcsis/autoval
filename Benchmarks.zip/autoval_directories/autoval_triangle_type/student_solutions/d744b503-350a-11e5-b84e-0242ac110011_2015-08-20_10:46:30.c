/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{
    int a,b,c; //input given
    scanf ("%d %d %d", &a,&b,&c); // scanning inputs
    if ((a+b>c) && (b+c>a) && (a+c>b)) // conditions for valid triangle
    {
        if ((a*a)+(b*b)==(c*c) || (a*a)+(c*c)==(b*b) || (b*b)+(c*c)==(a*a)) //conditions for right triangle
        {
            return 1;// printing 
        }
        else 
        if((a*a)+(b*b)>(c*c) && (a*a)+(c*c)>(b*b) && (b*b)+(c*c)>(a*a)) // conditions for acute triangle
        {
            return 2; // printing
        }
        else
        if((a*a)+(b*b)<(c*c) || (a*a)+(c*c)<(b*b) || (b*b)+(c*c)<(a*a) ) // conditions for obtuse triangle
        {
            return 3; // printing
        }
    }
    
        else {
            return -1; // printing invalid triangle
             }

    //return 0;

}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int student_solution(int input_a, int input_b, int input_c)
{ 
    int a,b,c;//varibles for 3 sides of the triangle.
    scanf("%d %d %d",&a,&b,&c);
    int larg=a;//varibale for largest side,assuming a is the largest.
    if((b>a)&&(b>c))/*condition for b to be largest*/
    {
        larg=b;//larg changed to b
    }
    else if((c>a)&&(c>b))//condition for c to be largest
    {
        larg=c;//larg changed to c
    }
    if((a<(b+c))&&(b<(a+c))&&(c<(a+b)))/*condition for triangle to exist*/
    {
        if(larg==a)
        {
            if((a*a)>((b*b)+(c*c)))/*square of largest side is greater than the sum to squares of other two side for obtuse*/
            {
                return 3;
            }
            else if((a*a)<((b*b)+(c*c)))/*square of largest side is less than the sum to squares of other two side for acute*/
            {
                return 2;
            }
            else if((a*a)==((b*b)+(c*c)))/*square of largest side is equal to the sum to squares of other two side for right angled*/
            {
                return 1;
            }
        
        }
        if(larg==b)//if larg is b
        {
            if((b*b)>((a*a)+(c*c)))/*square of largest side is greater than the sum to squares of other two side for obtuse*/
            {
                return 3;
            }
            else if((b*b)<((a*a)+(c*c)))/*square of largest side is less than the sum to squares of other two side for acute*/
            {
                return 2;
            }
            else if((b*b)==((a*a)+(c*c)))/*square of largest side is equal to the sum to squares of other two side for right angled*/
            {
                return 1;
            }
    
        }
        if(larg==c)//if larg is c
        {
            if((c*c)>((b*b)+(a*a)))/*square of largest side is greater than the sum to squares of other two side for obtuse*/
            {
                return 3;
            }
            else if((c*c)<((b*b)+(a*a))/*square of largest side is less than the sum to squares of other two side for acute*/)
            {
                return 2;
            }
            else if((c*c)==((b*b)+(a*a)))/*square of largest side is equal to the sum to squares of other two side for right angled*/
            {
                return 1;
            }

    
        }
    }
    else //if above condition fails
    {
        return -1;
    }
    //return 0;
}
#include <stdio.h>
#define scanf(str, x, y, z); *x=input_a;*y=input_b;*z=input_c;

int golden_solution(int input_a, int input_b, int input_c) {

	int a ,b , c , t;
	scanf("%d%d%d" , &a , &b , &c); 

	if (a > c)  //swap a & c
	{	t = c;
		c = a;
		a = t;
	}

	if (b > c)  //swap b & c
	{
		t = c;
		c = b;
		b = t;
	}
	// now c is the longest side

	if ( a + b <= c || b + c <= a || a + c <= b)
		return -1;

	else if (c*c > a*a + b*b)
		return 3;

	else if (c*c < a*a + b*b)
		return 2;

	else
		return 1;

	
	//return 0;
}
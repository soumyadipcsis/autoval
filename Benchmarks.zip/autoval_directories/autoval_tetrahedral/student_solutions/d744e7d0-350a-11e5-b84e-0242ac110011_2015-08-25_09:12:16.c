/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int sum,i,j,T,n;
	scanf("%d",&n);
	T=0;
	for(i=1;i<=n;i=i+1){
	    sum=0;
	    for(j=1;j<=i;j++){
	        sum=sum+j;
	    }
	    T=T+sum;
	}
	return("%d",T);
	//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int N;            // Number to be checked
	int i=1,sum=0;
	scanf("%d",&N);
	while(i<=N)
	{
	    int j=1;
	    while(j<=i)
	    {
	        sum=sum+j;
	        j++;
	    }
	    i++;
	}
	return("%d",sum);
	//return 0;
}
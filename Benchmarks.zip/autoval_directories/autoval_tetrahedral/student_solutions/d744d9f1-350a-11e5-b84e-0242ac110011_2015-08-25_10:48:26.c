/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){              
	int n,s=0,T=0;       // //s is the each term of the series,T is the                                         nth tetrahedral number.//
	int i=0;
	scanf("%d",&n);      //the for loop//
	for(i=1; i<=n; i=i+1){
	  s=s+i;
	  T=T+s;}
	  return("%d",T);
	//return 0;
}
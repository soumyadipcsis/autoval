/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int N,i,j,sum=0;
    scanf("%d",&N);
    for(i=1;i<=N;i++)   //to control the number of terms
    {
        for(j=1;j<=i;j++)  //for adding numbers in each term
        {
            sum=sum+j;  //to store the total sum
        }
    }
    return("%d",sum);
	//return 0;
}
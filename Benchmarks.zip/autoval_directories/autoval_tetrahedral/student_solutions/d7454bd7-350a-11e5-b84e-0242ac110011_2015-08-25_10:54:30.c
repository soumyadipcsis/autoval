/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

    int student_solution(int input_N) {
    int i,n,T=0;            // initializing the variables i,n and T
                            // here, T is the required sum
    
    scanf("%d",&n);         // input to be taken by the user
    
    for (i=0;i<=n;i=i+1){
        T=T+(i*(i+1)/2);
                            // the formula of the sum of n numbers is 
                            //(n*(n+1)/2)  
    }
    
    return("%d",T);
    
    //return 0;
}
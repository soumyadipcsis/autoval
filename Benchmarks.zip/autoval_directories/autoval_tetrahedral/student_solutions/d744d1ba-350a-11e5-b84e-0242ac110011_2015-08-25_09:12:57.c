/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
	int j, N, tet_sum=0;   //declaration.
	scanf("%d", &N);       //reading input.
	 while (N>0)
	 {
	     j=N;
	     while(j>0) 
	     {                 //summation(n) is computed in inner loop.
	          tet_sum=tet_sum+j;
	          j--;   
	     }                 //N is decremented each time in outer loop to
	     N--;              //compute (summation(n to 1)-summation (n).)  
	 }                 
	 return("%d", tet_sum);
	//return 0;
}
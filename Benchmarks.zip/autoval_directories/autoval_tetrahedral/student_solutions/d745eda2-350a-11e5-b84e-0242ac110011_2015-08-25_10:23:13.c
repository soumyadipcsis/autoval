/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
	int n=0;
	 int s=0;                  //variable to store each term of series
	 int sum=0;                //variable to store sum of series 
	 scanf("%d",&n);
	  for(int i=1;i<=n;i++)    //calculating 's' and adding it in 'sum'
	  {   
	     s=s+i; 
         sum=sum+s;
	  }
	  return("%d",sum);
	//return 0;
}
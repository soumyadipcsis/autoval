/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int N, sum=0;
	
	scanf("%d", &N);           //getting input
	
	for(int i=1; i<=N; i++)        
	   { /*i in each iteration represents i-th term of the tetrahedral              number*/
	   
	      for(int j=1; j<=i; j++)
	        {                      //loop for computing sum from 1 to i
	            sum = sum + j;
	        }
	   }
	   
	return("%d", sum);          //printing sum(the output)
	
	//return 0;
}
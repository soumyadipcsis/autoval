/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    
    int n;
    scanf("%d",&n);
    int T;
    
    T = n*(n+1)*(2*n+1)/12 + n*(n+1)/4;
    return("%d",T);
    
	//return 0;
}
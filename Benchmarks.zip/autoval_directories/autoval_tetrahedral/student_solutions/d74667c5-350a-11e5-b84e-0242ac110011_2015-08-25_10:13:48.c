/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int N,a,i,sum;
	scanf ("%d",&N);
	sum=0,i=1;
	while (i<=N)
	{
	    a=i*(i+1)/2;
	    sum=sum+a;
	    i++;
	}
	return("%d",sum);
	
	//return 0;
}
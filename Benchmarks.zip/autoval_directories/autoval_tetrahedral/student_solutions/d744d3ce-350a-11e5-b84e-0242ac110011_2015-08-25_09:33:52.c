/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int N,i,j;
	int s=0;    //To keep sum 0 intially
	scanf("%d",&N);
	
	//Outer loop for summing different "terms" of T(n)
	//like (1), (1+2), (1+2+3) and so on.
	for(i=1; i<=N; i++)
	{
	    //Inner loop to sum no.s in each "term".
	    for(j=1; j<=i; j++)
	    {
	        s+=j;  
	    }
	}
	return("%d",s);
	//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int sum,i,j,n;
	sum=0;
	scanf ("%d",&n);               //read n
	for (i=1;i<=n;++i) {            //first loop
	    for (j=1;j<=i;++j) {        //second loop
	        sum =sum+j;
	    }
	}
	return ("%d",sum);
	//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    int n, i, s=0, ans=0;
    scanf("%d",&n);//input n
    for(i=0; i<=n; i++){//nth term
        s=s+i;//loop for sum upto n
        ans=ans+s;//loop for tetrahedral no.
    }
    return("%d",ans);//print tetrahedral no.
	//return 0;
}
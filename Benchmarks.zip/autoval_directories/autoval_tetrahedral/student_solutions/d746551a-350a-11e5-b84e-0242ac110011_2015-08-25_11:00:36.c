/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int N,i,j,sum=0;
	scanf("%d",&N);/*asking the user to enter number*/
	for(i=1;i<=N;i++)
	{
	   for(j=1;j<=i;j++)/*loop to give repeated iteration from 1*/
	       sum=sum+j;/*adding each small parts and also retaining previous one*/
	}
	return("%d",sum);/*printing output*/
	//return 0;
}
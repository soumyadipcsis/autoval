/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    int n,i;
    int sum=0;
    scanf("%d",&n);
    for ( i=1;i<=n;i++){
    sum=sum+ (i*(i+1))/2;
    
    }
	return("%d",sum);
	//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int a,i,j,sum=0; //declaring vaiable
	scanf("%d",&a); //taking input
	for(i=1;i<=a;i++) // defining bracket of sum
	{
	    for(j=1;j<=i;j++) // doing sum of that bracket
	    {
	    sum=sum+j; 
	    }
	}
	return("%d",sum); //printing sum 
	//return 0;
}
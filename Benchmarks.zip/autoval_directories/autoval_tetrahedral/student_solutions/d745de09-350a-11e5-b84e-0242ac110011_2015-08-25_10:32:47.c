/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int N;
	int sum=0;
	scanf("%d",&N);
	for(int i=1;i<=N;i++)//gives the number of the term of the series..say 2nd term which is (1+2).
	{
	    for(int j=1;j<=i;j++)//sum of terms in the nth term..i.e; (1+2+3+..n) this sum is added to the sum of the total terms till (n-1)th term
	    {   
	        sum=sum+j;
	    }
	}
	return("%d",sum);
	//return 0;
}
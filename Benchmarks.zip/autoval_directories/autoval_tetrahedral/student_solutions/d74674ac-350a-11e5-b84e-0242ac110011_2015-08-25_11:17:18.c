/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;
//to find the nth tetrahedral number
int student_solution(int input_N){
int a;
int b;
int c;
int sum = 0;
scanf("%d",&b);
for(a=1;a<=b;a++)
{
    for(c=1;c<=a;c++)
    {   
        sum = sum+c;
    }
}
return("%d",sum);
	//return 0;
}
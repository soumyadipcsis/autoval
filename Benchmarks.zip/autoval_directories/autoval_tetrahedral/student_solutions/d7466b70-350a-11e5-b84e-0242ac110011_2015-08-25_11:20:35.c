/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int n;
    int a=0;
    scanf ("%d",&n);
    if (n<0){
        return("enter a number above 0");
        scanf("%d",&n);
    }
     for (int i=1;i<=n;i++)
     {
         a=a+(i*(i+1)/2);
     }
     return("%d",a);
	//return 0;
}
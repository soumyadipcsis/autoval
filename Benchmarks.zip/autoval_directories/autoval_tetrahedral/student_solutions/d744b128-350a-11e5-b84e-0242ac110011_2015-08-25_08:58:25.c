/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{   
    int i,n,sum=0,j;
    scanf("%d",&n);
    for(i=1;i<=n;i++)   //each i corresponds to a bracket
    {
        for(j=1;j<=i;j++)
        {
            sum=sum+j;  //summing the values of j in a bracket upto the                            value of corresponding i
        }
    }
    return("%d",sum);
	//Enter your code here
	//return 0;
}
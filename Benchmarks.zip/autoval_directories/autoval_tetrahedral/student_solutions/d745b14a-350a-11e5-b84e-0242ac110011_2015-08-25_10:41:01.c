/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    int i,j,sum=0,n;
    scanf("%d",&n);// n is the number entered
    for(i=1;i<=n;i++)//for loop to carry out the sum of inner for loop sums
    {
        for(j=1;j<=i;j=j+1)// for loop to carry out the sum of integers
        {
            sum=sum+j;
        }
    }
    return("%d",sum);// print the sum
	//return 0;
}
/*compile-errors:e158_277962.c:5:11: warning: expression result unused [-Wunused-value]
    for(;n>=0,i<=n;i++)//starting a loop
         ~^ ~
e158_277962.c:4:9: warning: variable 'n' is used uninitialized whenever function 'main' is called [-Wsometimes-uninitialized]
int i=1,n,sum=0,x;
~~~~~~~~^
e158_277962.c:5:10: note: uninitialized use occurs here
    for(;n>=0,i<=n;i++)//starting a loop
         ^
e158_277962.c:4:10: note: initialize the variable 'n' to silence this warning
int i=1,n,sum=0,x;
         ^
          = 0
2 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
int i=1,n,sum=0,x;
    for(;n>=0,i<=n;i++)//starting a loop
    {scanf("%d",&n);//input here
       x=i*(n-i+1);
       sum = sum + x;}
return("%d",sum);//prints the output
	
	//return 0;
}
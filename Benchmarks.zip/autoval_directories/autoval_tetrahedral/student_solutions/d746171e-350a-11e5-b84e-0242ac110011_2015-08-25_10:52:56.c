/*compile-errors:e158_277956.c:6:9: warning: unused variable 'n' [-Wunused-variable]
int i,j,n,sum=0;
        ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
int num;//number//
scanf("%d",&num);
int i,j,n,sum=0;
scanf("%d",&num);
for(i=0;i<=num;i=i+1){ //outer loop//
for(j=0;j<=i;j=j+1){//inner loop//
sum=sum+j;
      }
   }
return("%d",sum);
//Enter your code here
	//return 0;
}
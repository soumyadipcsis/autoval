/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    int T,S,i,N;
    i = 0;
    S = 0;
    T = 0;
    
    scanf("%d",&N);
    
    while (i<N)
    {
    i++; //Computing the ith term.
    
    S = S + i; //Computing the sum of i numbers.
    
    T = T + S; //Computing the ith tetrahedral number.
    }
    
    return("%d",T); //Displaying the nth tetrahedral number.
    
	//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N; //including input output package

int student_solution(int input_N) //opening main method
{
    int n,i,j,final_sum=0,sum=0; //declaring variables
    scanf("%d",&n);       //taking input from user
    for(i=1;i<=n;i++)  //for loop for number of terms in tetrahedral no.
    {
        for(j=1;j<=i;j++) //for loop for calculating sum of a term
        {
            sum=sum+j; //calculating sum of one term
        }
        final_sum=final_sum+sum; //calculating the sum of all terms
        sum=0;  
    }
	return("%d",final_sum); //printing Nth tetradedral number
	//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	
	int N;
	int i;
	int sum=0; //initialising sum
	
	scanf("%d",&N);// taking input
	
	  for (i=1;i<=N;i++){  
	      
	       int j;
	       
	       for (j=1;j<=i;j++){
	          
	            sum=sum+j;    //adding each term
	          
	       }
	    
	  }
	
	return ("%d",sum);//printing sum
	
	//return 0;
}
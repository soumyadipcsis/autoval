/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    int N,s,r,p=0;
    scanf("%d",&N);
    for(s=1;s<=N;s++){
        for(r=1;r<=s;r++){
            p=p+r;
        }
        
    }
	return("%d",p);
	//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    int i,j,k,sum=0;
    scanf("%d",&j);
    for(i=1;i<=j;i++){
        //sum of the number till starting from 1 to that no.
    for(k=1;k<=i;k++)    
        sum = sum + k;
        //total sum
    }
	return("%d",sum);
	
	//return 0;
}
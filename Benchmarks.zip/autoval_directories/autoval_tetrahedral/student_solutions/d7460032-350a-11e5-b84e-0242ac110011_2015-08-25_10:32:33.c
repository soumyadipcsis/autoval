/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int i,sum=0,n;
	scanf("%d",&n);
	for(i=1;i<=n;i=i+1)
	{int j;
	for(j=1;j<i;j=(j+1))
	{sum=sum+j;
	continue;}
	sum=(sum+i);
	}
	return("%d",sum);
	//return 0;
}
/*compile-errors:e158_277919.c:4:10: warning: unused variable 't' [-Wunused-variable]
   int n,t=0,k=0,i,j;//declaring variables
         ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
   int n,t=0,k=0,i,j;//declaring variables
   scanf("%d",&n);
   for(i=0;i<=n;i++)//aplying loop
   {
    for(j=1;j<=i;j++)
    {
        k=k+j;
    }
   }
   return("%d",k);//printing t(n)
	//return 0;
}
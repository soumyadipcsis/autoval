/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    int n;
    int p= 0;//used to store the sum
    scanf("%d",&n);
    if(n<0){
        return("please enter a number above 0");
        scanf("%d",&n);/*if the number is negative ... then this will be excuted and it will ask again*/
    }
    
    for(int i=1;i<=n;i++){
        p=p+((i*(i+1))/2);
    }
    return("%d",p);
	//return 0;
}
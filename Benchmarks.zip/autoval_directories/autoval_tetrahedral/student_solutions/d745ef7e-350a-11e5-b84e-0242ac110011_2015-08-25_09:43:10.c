/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int i,n,sum=0; //declaration of 3 variables
	scanf("%d",&n); //taking input from user
	for (i=1;i<=n;i++) { //initialisation expression,test expression,update expression
	    sum=sum+((i*(i+1))/2); //computing nth tetrahedral sum
	}
	return ("%d",sum); //printing output
	//return 0;
}
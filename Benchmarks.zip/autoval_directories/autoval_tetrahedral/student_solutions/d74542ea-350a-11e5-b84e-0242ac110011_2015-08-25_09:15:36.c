/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int n,i,j,fsum=0;       //declaring variables
	scanf("%d",&n);         //taking input
	for(i=1;i<=n;i++)       //initialization loop
	{
	    for(j=1;j<=i;j++)   //nested loop for adding each term 
	    {
	        fsum=fsum+j;    //adding each term to get final sum
	    }                   //that is adding 1,2,...so on upto j<=i
	}                       //to the previous fsum
	return("%d",fsum);      //printing required  output
	//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int i;
	int j;
	int k;
	int sum=0;
	scanf("%d",&j);
	for(i=1;i<=j;i++) //first loop begins.
	{
	   
	    for(k=1;k<=i;k++) // second loop inside the first loop.
	    {
	        sum=sum+k;

	    }
	    
	}
	
	return("%d",sum);
	//return 0; 
}
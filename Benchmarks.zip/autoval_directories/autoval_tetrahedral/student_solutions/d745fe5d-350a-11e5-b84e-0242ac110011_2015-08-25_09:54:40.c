/*compile-errors:e158_277947.c:13:18: warning: more '%' conversions than data arguments [-Wformat]
            return("%d+%d",i);
                       ~^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int n,i;
	int sum=0;
	return("5:");
	scanf("%d",&n);
	sum=(n*(n+1))/2;
	return("sum of series:");
	for(i=1;i<=n;i++)
	{
	    if (i!=n)
	    return("%d+%d",i);
	    else
	    return("%d=%d",i,sum);
	}
	//return 0;
}
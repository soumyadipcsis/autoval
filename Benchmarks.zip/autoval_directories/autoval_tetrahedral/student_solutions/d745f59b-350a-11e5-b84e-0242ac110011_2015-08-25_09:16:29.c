/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int n,i,j,sum;         //declared all the required variable
	scanf("%d",&n);        //input the value of n
	sum=0;            //initially the sum of terms is taken to be zero
	i=1;                    //assigning initial value 1 to i
	while(i<=n)
	{
	    j=1;               //assignining initial value 1 to j
	    while(j<=i)        //condition 
	    {
	        sum = sum+j;   //adding j to sum
	        j=j+1;         //update statement for inner while loop
	    }
	    i=i+1;             //update statement for outer while loop
	}
	return("%d",sum);
	//return 0;
}
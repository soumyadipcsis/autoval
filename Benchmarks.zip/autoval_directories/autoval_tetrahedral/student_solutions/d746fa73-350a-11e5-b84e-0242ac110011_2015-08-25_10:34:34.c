/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
	int i,n;
	int num=0,sum=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
	    num=num+i;
	    sum=sum+num;/*this sum will finally give nth tetrahedral          number*/
	}
	return("%d",sum);
	//return 0;
}
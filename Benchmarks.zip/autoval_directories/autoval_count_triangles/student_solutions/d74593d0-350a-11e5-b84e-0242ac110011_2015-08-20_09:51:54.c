/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int n,c=0;
    scanf("%d\n",&n);
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=i;j++)// loop till i to avoid repetition in counting
        {
            for(int k=1;k<=j;k++)// loop till j to avoid repetition in counting
            {
                if(((i+j)>k) && ((i+k)>j) && ((j+k)>i))
//condition for a triangle:Sum of two sides is greater than the third
                c=c+1;  //counting the number of possible triangles
            }
        }
    }
    return("Number of possible triangles is %d\n",c);
    //return 0;
}
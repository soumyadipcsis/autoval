/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int i,j,k,n,s=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++)
        {
            for(k=1;k<=n;k++){
                if(i>=j && i>=k && j+k>i && j>=k){
                    s=s+1;//triangles added one by one
                    }
            }
        }
    }
    return("Number of possible triangles is %d",s);// Fill this area with your code.
    //return 0;
}
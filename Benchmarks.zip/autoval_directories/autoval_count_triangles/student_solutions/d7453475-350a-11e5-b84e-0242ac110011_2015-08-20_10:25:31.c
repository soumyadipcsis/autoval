/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{int N;
scanf("%d",&N);          //reading input from the user.
int a,b,c;               //consider sides a,b,c of triangle.
int count=0;             //assign a variable to calcuate no of triangles.
for (a=1;a<=N;a++)       //consider a loop for side a
{ for (b=1;b<=a;b++)      //consider a nested loop into  a for side b.
    { for (c=1;c<=b;c++)    //consider a nested loop into b for  side c.
       { if (b+c>a)       //check if it is a valid triangle.
         
          count=count+1;  //calculate the no. of such valid triangles.
          
       }
    }
 } return("Number of possible triangles is %d",count);   //display the output to the user.
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int a;
    int cnt=0;
    scanf("%d",&a);
     for(int i=1;i<=a;i++)
        {
     for(int j=i;j<=a;j++)
        {
     for(int k=j;k<=a;k++)
        { 
           if((i+j>k)&&(j+k>i)&&(i+k>j))//condition
           cnt++;                       //counting triangle
        }
        
        }
        }
        return("Number of possible triangles is %d",cnt);//output
    //return 0;
}
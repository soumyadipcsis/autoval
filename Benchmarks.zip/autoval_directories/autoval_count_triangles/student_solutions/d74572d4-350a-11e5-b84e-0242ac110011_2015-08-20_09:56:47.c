/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;
  
int student_solution(int input_N)
{ 
  
  
  
//return 0;
}

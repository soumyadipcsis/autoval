/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
   int n;
   scanf("%d",&n);
   int a=1,b,c,i=0;//i=no of triangles.a,b,c are sides
   while(a<=n){
       b=1;
       while(b<=a){
           c=1;
           while(c<=b){
                 if(a+b>c && b+c>a && a+c>b){
                            //cheking whether it is triangle or not
                  i++;      //counting triangls
                }
            c++; 
            }
        b++;  
        }
    a++;    
    }
     
     return("Number of possible triangles is %d",i);
    //return 0;
}
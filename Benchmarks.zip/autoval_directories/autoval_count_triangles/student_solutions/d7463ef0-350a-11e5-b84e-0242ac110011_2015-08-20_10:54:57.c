/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{ int N; 
int i,j,k; 
 int count=0; 
 scanf("%d",&N);
  for (i=1; i<=N; i=i+1)  
  {
      for (j=i; j<=N; j=j+1)
     {
         for (k=j; k<=N; k=k+1)
     {     if (i+j>k && j+k>i && i+k>j)
     count=count+1; /* Count number of possible triangles */
     }
     }
  } 
  return ("Number of possible triangles is %d",count);
    //return 0;
}
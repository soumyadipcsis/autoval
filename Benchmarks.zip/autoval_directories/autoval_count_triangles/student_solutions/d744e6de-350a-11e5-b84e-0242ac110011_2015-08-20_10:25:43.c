/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int n;//varibale to take a natural no. from the user.
    int count=0;//variable to store no. of possible triangles.
    scanf("%d",&n);
    for(int c=1;c<=n;c++)/*variable for side 1 of the triangle,for loop to start from 1 and go till n*/
    {
        for(int b=c;b>=1;b--)/*nested for loop for the side 2(b) of the traingle,will always be less than c*/
        {
            for(int a=b;a>=1;a--)/*nested loop for the side 3 of the traingle,will always be less than b*/
            {
                if((a+b)>c)//condition for the triangle to exist
                {
                    count=count+1;//increment by 1 if condition is true
                }
            }
        }
    }
    return("Number of possible triangles is %d",count);
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
int n,a,b,c;
int p=0;
scanf("%d",&n);
for(a=n;a>=1;a--){
   for (b=a;b>=1;b--){
      for (c=b;c>a-b;c--){
       p=p+1;
      }
   }
}
 return("Number of possible triangles is %d",p); 
    //return 0;
}
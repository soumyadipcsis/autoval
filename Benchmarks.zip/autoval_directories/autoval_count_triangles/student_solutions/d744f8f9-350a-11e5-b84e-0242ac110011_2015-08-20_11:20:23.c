/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
   int N;
   int a; int b; int c;
   int i; i=0;
   scanf("%d",&N); //input N
   for (a=1; a<=N; a=a+1) { //loop 1 asign a
        for (b=1; b<=N; b=b+1) { //loop 2 asign b
            for (c=1; c<=N; c=c+1) { //loop 3 asign c
                if (a+b>c) {  //basic condition for triangle
                   i=i+1; 
                }
            }
        }
    }
     return("Number of possible triangles is %d",i/N); //Total no. of                                                        triangle possible
    //return 0;
}
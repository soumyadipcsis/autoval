/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N){
    
    int n;                 // initialization
        scanf("%d",&n);   // take input
    
    int i,j,k,d;          // creating new variable
      d=0;
         for (i=0; i<=n; i++) //  evaluating 1st variable
         { 
             for (j=i; j<=n; j++)// evaluating 2nd variable
             { 
                 for (k=j; k<=n; k++) // evaluating 3rd variable
                 { 
                     if( i+j>k && i+k>j && j+k>i) //checking final condition
                     
    d++;
        }
          }
            }
    return("Number of possible triangles is %d",d); // to print result
    
    //return 0;
}
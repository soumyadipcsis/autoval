/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int i,j,k,n,count;
    count=0;//for counting number of triangles
    scanf("%d",&n);//user enters desired number.
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            for(k=1;k<=j;k++)
            {
                if(((i+j)>k)&&((i+k)>j)&&((j+k)>i))
                count++;//as soon as the condition for triangle is                               verified,counter increases
            }
        }
    }
    return("Number of possible triangles is %d",count);
    //return 0;
}
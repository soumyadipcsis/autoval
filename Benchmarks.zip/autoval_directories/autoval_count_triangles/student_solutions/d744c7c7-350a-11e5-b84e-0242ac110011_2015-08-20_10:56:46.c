/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int N,a,b,c,count;
        count=0;/*initial count be zero*/
    scanf("%d",&N);/*input a number*/
    for(a=1;a<=N;a=a+1)
    for(b=1;b<=a;b=b+1)
    for(c=1;c<=b;c=c+1)
    {
     if(a+b>c&&b+c>a&&c+a>b&&a-b<c&&b-c<a&&c-a<b)/*cndition satisfied*/
       count=count+1;
    }
    return("Number of possible triangles is %d",count);/*number of triangles formed*/
    //return 0;
}
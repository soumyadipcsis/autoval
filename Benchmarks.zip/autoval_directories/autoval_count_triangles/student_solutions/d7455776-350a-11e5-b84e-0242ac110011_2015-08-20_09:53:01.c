/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
   int N,a,b,c,count;
   scanf ("%d",&N);
   a=1; b=1; c=1; // a,b,c are sides of a triangle
   count=0;// count represents no of triangles
   for (a=1;a<=N;a=a+1)
   {for (b=1;b<=a;b=b+1)
    {for (c=1;c<=b;c=c+1)
  
   
   {if (a<(b+c))
   count = count + 1;}
       
   }}
   return("Number of possible triangles is %d", count);
   
   
   
    //return 0;
}
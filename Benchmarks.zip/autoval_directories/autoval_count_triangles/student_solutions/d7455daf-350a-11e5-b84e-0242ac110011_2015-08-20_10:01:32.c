/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int i,j,k,n,c=0;    // 'c' for storing number of triangles 
    scanf("%d",&n);
    for( i=1;i<=n;i++)  // 'i' as one of the sides of triangle
    {
     for( j=i;j<=n;j++) // 'j' as another side of triangle
     {
      for( k=j;k<=n;k++)// 'k' as last side of triangle
      {
       if((i+j>k)&&(j+k>i)&&(k+i>j))// checking property of triangle
       c=c+1;
      }
     }
    }
    return("Number of possible triangles is %d",c);
    //return 0;
}
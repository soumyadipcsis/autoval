/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;
int student_solution(int input_N)
{ int N;
   scanf("%d",&N);//input from the user
   int T=0;// 'T' denotes the number of trianges possible       
   // variables introduced to represent the sides of triangle
   int a=1; //initialising the variable
   int b=1;
   int c=1;
   while (a<=N) 
   {    while (b<=N) 
        {   while(c<=N) 
            {   if (a+b>c)//sum of 2 sides must be greater thaan 3rd 
                {
                   T=T+1;//updating  variable
                } 
              c=c+1; //updating  variable
            } b=b+1;
              c=b;//it is done so that extra cases will be rejected and                    c will not start again from 1
        } a=a+1;
          c=a;
          b=a;
   }
   return("Number of possible triangles is %d",T) ;
   //return 0;
}
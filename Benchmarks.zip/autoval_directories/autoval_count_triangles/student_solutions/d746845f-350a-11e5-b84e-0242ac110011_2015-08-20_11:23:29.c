/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{int a,b,c,N,count=0;
scanf("%d",&N);
for(a=1;a<=N;a++){
    for(b=1;b<=a;b++){
        for(c=1;c<=b;c++){
            if(a<b+c && b<a+c && c<a+b)
            {
              
                count++;
            }
        }
    }
}
    return("Number of possible triangles is %d",count);


    // Fill this area with your code.
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int N;
    scanf("%d",&N);
    int i,j,k;
    int count=0;          //for counting no of possible triangle
    for(i=1;i<=N;i=i+1)   //loop for first side length
    {
        for(j=i;j<=N;j=j+1) //loop for second side length
        {
            for(k=j;k<=N;k=k+1) //loop for third side length
            {
                if(((i+j)>k)&&((j+k)>i)&&((i+k)>j)) //valid triangle
                {
                    count=count+1;
                }
            }
        }
    }
    return("Number of possible triangles is %d",count);
    //return 0;
}
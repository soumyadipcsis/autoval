/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{ 
    int p,q,r,N; /* p,q,r are sides of triangle */
    scanf("%d",&N);
    int c = 0;
        for(p=1;p<=N;p=p+1){ /* Given : p,q,r are less than equal to N */
          for(q=1;q<=p;q=q+1){
              for(r=1;r<=q;r=r+1)
              if(p<q+r){ /*Condition for existence of triangle */
                  c=c+1;
              }
          }
        }
 return("Number of possible triangles is %d",c);

    
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{ 
    /*DECLARING VARIABLES
    N TO ENTER FROM USER
    count TO COUNT NO OF POSSIBLE TRIANGLES
    */
    int N,count=0;
    scanf("%d",& N);
    /* USING NESTED LOOP SUCH A WAY THAT i IS LARGEST SIDE ,j IS SECOND      LARGEST AND K IS SMALLEST*/
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=i;j++)
        {
            for(int k=1;k<=j;k++)
            { 
/*CHECKING CONDITION FOR TRIANGLE  
  SUM OF TWO SIDES IS GREATER THAN LARGEST SIDE
  DIFFERENCE OF TWO SIDES IS LESS THAN SMALLEST SIDE*/
                if(((j+k)>i)&&((i-j)<k))
                count++;//INCREMENT OF count BY ONE
            }
        }
    }
    //PRINTING NUMBER OF POSSIBLE TRIANGLES
    return("Number of possible triangles is %d",count);
    //return 0;
}
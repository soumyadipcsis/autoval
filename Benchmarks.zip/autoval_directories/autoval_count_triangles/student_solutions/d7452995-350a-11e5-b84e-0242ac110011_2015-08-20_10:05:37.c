/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
/*to calculate the number of triangles with integral sides which can be formed with side lengths less than or equal to n*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;
int student_solution(int input_N)
{
    int n,a=0,i,j,k;//i,j,k are sides of triangle such that 
    scanf("%d",&n);//to scan input
    
    for(i=1;i<=n;i++)
    {
      
        for(j=1;j<=i;j++)
        {
       
            for(k=1;k<=j;k++)
            {
             if(i<(j+k))//condition for a triangle to be possible
             {
                 a=a+1;//a is the no. of possible triangles
             }
            }
        }
    }
    return("Number of possible triangles is %d",a);
    
    //return 0;
}
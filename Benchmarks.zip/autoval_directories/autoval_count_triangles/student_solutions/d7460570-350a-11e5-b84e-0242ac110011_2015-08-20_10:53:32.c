/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
int x;
scanf("%d",&x);/*x is input*/
int i,j,k;/*I am taking i,j,k as three sides of triangle*/
int count=0;
for(i=1;i<=x;i=i+1){
    for(j=1;j<=i;j=j+1){
        for(k=1;k<=j;k=k+1)/*I HAVE TAKEN i>=j>=k*/
        if(j+k>i)/*as above we know that i is greatest*/ {
            count++;    
        }
}}
return("Number of possible triangles is %d",count);
    //return 0;
}
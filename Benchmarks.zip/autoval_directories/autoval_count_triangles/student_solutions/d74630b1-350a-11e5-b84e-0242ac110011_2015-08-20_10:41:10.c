/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
int N;
scanf("%d",&N);
int a;
int b;
int c;
int x;/*defining variables*/
for(x=0,a=1;a<=N;a=a+1){/*initializing side a & limiting its value                             upto N*/
    for(b=1;b<=a;b=b+1){/*initializing side b & limit its value to a                          so cases don't reapeat*/
        for(c=1;c<=b;c=c+1){/*initializing side c*/ 
             if((a+b>c)&&(a+c>b)&&(b+c>a)){/*condition for valid                                                  triangle*/
         x=x+1;/* adding the case to our count*/
             }
        }
        
    }
    
}

return("Number of possible triangles is %d",x);
    
    //return 0;
}
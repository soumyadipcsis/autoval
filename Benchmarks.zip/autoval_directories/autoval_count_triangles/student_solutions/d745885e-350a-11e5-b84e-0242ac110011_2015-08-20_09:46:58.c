/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{  int n,i,j,count,a;
   scanf("%d",&a);
   count = 0;
    for(n=1;n<=a;n++)  //     
    {
        for(i=1;i<=n;i++) // as n goes from 0 to a, we set i (2nd side) to go from 1 to a
          {   
              for(j=1;j<=i;j++) /* we know loop 3rd side, and check condition of existence of triangle. also note that, its max limit should be i, otherwise there will be repetition. */ 
              { 
                  if(i+j>n)
                   {count++;} // count increases after each valid pair
              }   
          }
    }
    return("Number of possible triangles is %d",count);
    //return 0;
}
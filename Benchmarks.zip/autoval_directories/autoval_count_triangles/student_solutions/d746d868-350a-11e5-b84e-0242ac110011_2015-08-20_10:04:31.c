/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;
          /*print number of possible triangle*/
int student_solution(int input_N)
{
    int N,a,b,c;
    int d=0;
    scanf("%d",&N);
    for(a=1;a<=N;a=a+1){         
                                /*condition on first side of triangle*/
        for(b=1;b<=a;b=b+1){     
                                /*condition on second side of triangle*/
            for(c=1;c<=b;c=c+1){ 
                                /*condition on third side of triangle*/
        if ((a<b+c)&&(b<c+a)&&(c<a+b))
        {d=d+1;}
            }        
        }
    }
        return("Number of possible triangles is %d",d);
}
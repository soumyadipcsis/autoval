/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int N,i,j,k;
    int t=0;
    scanf("%d",&N);
    for(i=1;i<=N;i++)//i is first side of triangle 
    {
        for(j=1;j<=i;j++)//j is second side of triangle
        {
            for(k=1;k<=j;k++)//k is third side of triangle
            {
                //i,j,k are in descending order as k<=j<=i
                if((k+j)>i)//Condition for valid triangle
                  t++;//t is the number of valid triangles
            }
        }
    }
    return("Number of possible triangles is %d",t);
    //return 0;
}
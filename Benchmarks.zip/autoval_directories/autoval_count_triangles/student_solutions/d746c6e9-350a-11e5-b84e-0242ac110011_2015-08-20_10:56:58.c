/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{  int a,b,c,n;
    scanf("%d",&n);//input n
     int z=0;//initilisation of z
    for(a=1;a<=n;a=a+1)//conditions on a using for loop
      {
          for(b=1;b<=a;b=b+1)// #to avoid repeatition b<=a
          {
              for(c=1;c<=b;c=c+1)// #to avoid repeatition c<=b 
              {
                  if((a+b)>c && (a+c)>c && (b+c)>a)//condition for valid triangle
                  {
                      z=z+1;//update z
                  }
              }
          }
      }
     return("Number of possible triangles is %d",z);

    //return 0;
}
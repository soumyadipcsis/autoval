/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
int N,x,y,z;
int num=0;
scanf("%d",&N);
for (x=1;x<=N;x=x+1)
{
    for(y=x;y<=N;y=y+1)
    {
        for(z=y;z<=N;z=z+1)
        {
            if ((x+y)>z&&(y+z)>x&&(x+z)>y)
            num=num+1;
        }
    }
}
return("Number of possible triangles is %d",num);
    //return 0;
}
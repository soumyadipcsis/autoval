/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int N,i,j,count,k;
    count=0;
    scanf("%d", &N);
    for(i=1;i<=N;i=i+1){
        for(j=i;j<=N;j=j+1){
            for(k=j;k<=N;k=k+1){
                if(i+j>k && i+k>j && j+k>i ){
            
                           count=count+1;
                          
                         
                }    
                
            }
        }
    }
        return("Number of possible triangles is %d", count);
    // Fill this area with your code.
    
}
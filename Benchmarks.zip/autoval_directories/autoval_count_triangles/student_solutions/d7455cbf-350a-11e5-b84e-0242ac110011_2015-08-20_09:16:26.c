/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int n,a=1,b=1,c=1,i;
    //a,b,c represent the sides of the triangle
    scanf("%d",&n);//given input by user
    i=0;
    for(a=1;a<=n;a++)
    {
    for(b=1;b<=a;b++)
    {
    for(c=1;c<=b;c++)
    {
     if(a+b>c&&b+c>a&&c+a>b)
     //sum of two sides should be greater than third side in a triangle
     {
        i++; 
     }
    }   
    }
    }
    //final value of variable i obtainede gives the no. of triangles
    return("Number of possible triangles is %d",i);
    //return 0;
}
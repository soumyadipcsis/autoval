/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
int num,tot;                  //variable for input,total count
int i,j,k;          //variables for all possible sides of triangle    
int ctr1=0,ctr2=0,ctr3=0;

scanf("%d",&num);

                //loop for checking all possible combination of sides
for(i=1;i<=num;i++)     
{
for(j=1;j<=num;j++)
{
for(k=1;k<=num;k++)
{ 
    if(i==j&&j==k&&k==i) //no of equilateral triangles
    ctr1++;
    
    else if((i+j>k)&&(j+k>i)&&(k+i>j)) 
    {
    if(i==j||j==k||k==i)   //no of isosceles triangles
    ctr2++;
                 
    else 
    ctr3++;                     //no of scalene triangles
    }
    
}
}
}
tot=(ctr1)+(ctr2/3)+(ctr3/6);   
   //total possible trngls after deleting the repeated triangles

return("Number of possible triangles is %d",tot);   

//return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int a,b,c,x=0;
    int n;
    scanf("%d",&n);
    for(a=1;a<=n;a=a+1) // increasing a from a=1 to a=n
        {
            for(b=1;b<=a;b=b+1)
            {
                for(c=1;c<=b;c=c+1)
                    if(a+b>c && b+c>a && c+a>b)\
                        {
                            x=x+1;
                        }
            }
        }
        return("Number of possible triangles is %d",x);
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
        int n,a,b,c;                            /*variable declaration*/
        
        int count=0;                         /*initialising loop counter*/

        scanf("%d",&n);
    
         for(a=1; a<=n; a++)                            /*beginning of loop*/
        
        
            {for(b=a; b<=n; b++)                    /*nested for loops*/
                
                
                  {for(c=b; c<=n; c++)
    
    
                    {if(a+b>c && a+c>b && b+c>a)             /*condition usage in loop*/
    
    
                       {count=count+1;                                                                                                              /*counting no of triangle*/
        
                }
        
            }
        
        }
        
    }                                                       /*loop termination*/
    
    
    return("Number of possible triangles is %d",count);  /*display result*/
    
    //return 0;
}
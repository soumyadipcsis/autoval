/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int N;
    scanf("%d",&N);
    int a;//a is any one side of the triangle
    int b;//b is any one side of the triangle
    int c;//c is any one side of the triangle
    int count=0;
    for(a=1;a<=N;a++)
    {
        for(b=a;b<=N;b++)
        {
            for(c=b;c<=N;c++)
            {
                if(a+b>c&&b+c>a&&c+a>b)
                {
                    count=count+1;
                }
            }
        }
    }
    return("Number of possible triangles is %d",count);
    //return 0;
}
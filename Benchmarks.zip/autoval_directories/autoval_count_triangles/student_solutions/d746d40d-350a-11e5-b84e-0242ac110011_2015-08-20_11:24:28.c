/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
/* to calculate the number of triangles with integral sides which can be
formed with side lengths less than or equal to N */
{
    int a;
    int b;
    int c;
    int N;
    int i=0;
    scanf("%d",&N);
    for(a=1;a<=N;a++)        //value of variable a lie between 1 and N
        for(b=1;b<=a;b++)    //value of variable b lie between 1 and a 
            for(c=1;c<=b;c++)//value of variable c lie between 1 and b
                if(a+b>c && b+c>a && a+c>b)
    /* condition for valid triangle i.e. sum of any 2 sides of 
    a trianglemust be greater than the third side*/
                    i++;
    //increment operator adds 1 to i if above condition is satisfied
    return("Number of possible triangles is %d", i);
}
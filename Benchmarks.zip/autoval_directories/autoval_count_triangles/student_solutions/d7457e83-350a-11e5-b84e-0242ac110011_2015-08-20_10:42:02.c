/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;
int student_solution(int input_N)
{
int i,j,k,n,s=0;
scanf("%d",&n);
    for(i=1;i<=n;i=i+1){
    for(j=1;j<=i;j=j+1){
        for(k=1;k<=j;k=k+1){
        if( (j+k>i) && (i+k>j) && (i+j>k) )
        s=s + 1;
        }
        }
        }
return("Number of possible triangles is %d",s );
    //return 0;
}
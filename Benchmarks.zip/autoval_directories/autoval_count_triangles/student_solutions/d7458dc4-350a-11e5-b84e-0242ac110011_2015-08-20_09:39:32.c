/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int N;/*define integers*/
    scanf("%d",&N);/*take input from user*/
    int a;
    int b;
    int c;
    int i=0;/*i gives number of triangles possible*/
    for (a=1;a<=N;a=a+1)/* assume a>b>c then if b+c>a then triangle is possible for a<=N*/
    {for (b=1;b<=a;b=b+1)
    {for (c=1;c<=b;c=c+1)
    if (b+c>a)
    {i=i+1;}/*increament i*/
    
}}
return("Number of possible triangles is %d",i);/*printf must be outside the loop*/
    //return 0;
}
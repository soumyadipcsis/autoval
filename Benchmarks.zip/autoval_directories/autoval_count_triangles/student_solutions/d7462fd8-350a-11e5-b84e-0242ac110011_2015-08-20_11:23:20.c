/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int N,a,b,c,count=0;    
    scanf("%d",&N);         
    for(a = 1; a<=N ; a = a + 1) 
    {
        for(b = 1; b<=a ; b = b + 1)
            for(c = 1; c<=b ; c = c + 1)  
                if ((a+b>c)&&(b+c>a)&&(c+a>b))//checking for valid triangles
                    {
                        count++;    //count of triangles
                    }                
    }
    return("Number of possible triangles is %d",count);
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int x,y,z,N;
    int count=0;
    scanf("%d",&N);
    
    for(x=1;x<=N;x++){
        for(y=1;y<=x;y++){
            for(z=1;z<=y;z++){
             if((x<y+z)&&(y<x+z)&&(z<x+y))
             count=count+1;
            }
        }
    }
    return("Number of possible triangles is %d",count);
    // Fill this area with your code.
    //return 0;
}
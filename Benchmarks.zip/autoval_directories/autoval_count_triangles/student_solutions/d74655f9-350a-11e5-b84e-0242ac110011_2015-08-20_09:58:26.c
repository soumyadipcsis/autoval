/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int a,b,c,N;//a,b,c sides of triangle & N is the no. to be input
    int n_o_t=0;    //no. of triangles
    scanf("%d",&N);
/*
  in the following code, to avoid repetitions a relation between
  a,b & c (a <= b <= c) is assumed because ((1,2,2),(2,1,2),(2,2,1))     is to be counted once.
  a takes all possible integers between 1 and N. 
  b takes all possible integers between a and N.
  c takes all possible integers between b and N.
  Triangle inequality is checked for each (a, b, c)
  if it is satisfied n_o_t is incremented.
                                                                   */
  
    for(a=1;a<=N;a++)   //min. value of a is 1 ('a' is a +ve integer)
    {
        for(b=a;b<=N;b++)                       //b>=a
        {
            for(c=b;c<=N;c++)                   //c>=b
            {
                if((a+b>c)&&(a+c>b)&&(b+c>a))   //Triangle inequality
                {
                    n_o_t++;//if a triangle is formed using a, b & c
                            //increment n_o_t by 1
                }    
            }
        }
    }
    return("Number of possible triangles is %d",n_o_t);
    //return 0;
}
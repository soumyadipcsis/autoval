/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{
    int x, y, z, N, no; //x, y, z are sides of triangle no is no. of possible triangles
    scanf("%d", &N);
    x=0, y=0, z=0, no=0;
    
    //x, y, z is the largest, 2nd largest, 3rd largest side side of a triangle This allows only distinct solutions. For a particular side, the value of other side is increased from 1 to test all cases 
    while(x<=N){          
        while(y<=x){
            while(z<=y){
                //triangle counted only when valid
                if((y+z>x)&&(x+z>y)&&(x+y>z)) 
                no=no+1;
                z=z+1;     //values of side increased from 0 to the side just longer than it(for y,z) and to N(for x)
            }
            //Value of side x, y again set to 1 to count all possibilities
            y=y+1;
            z=1;
        }
        x=x+1;
        y=1;
    }
    
    return("Number of possible triangles is %d", no);
    
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x); *x=input_N;

int student_solution(int input_N)
{   
    int n,a,b,c;                //declaring variables
    int count=0;
    scanf("%d",&n);
                        //getting possible sides of triangle using nested loops
    
    for(a=1;a<=n;a++)           
    {
        for(b=1;b<=a;b++)
        {   
            for(c=1;c<=b;c++)
            {                   // checking possible triangles from a,b and c
                
                if(((a+b)>c)&&((b+c)>a)&&((c+a)>b))
                {   
                   count=count+1;   // counting possible triangle
                }
            }
        }
    }    
    return("Number of possible triangles is %d",count);            

    
    //return 0;
}
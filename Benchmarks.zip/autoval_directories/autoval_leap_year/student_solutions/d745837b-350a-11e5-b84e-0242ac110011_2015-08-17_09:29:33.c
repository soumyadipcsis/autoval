/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)                    //function declaration
{
    int year;year = input_year;;                   //variable declared
    //scanf("%d",&year);          //read into year
    if((year%100==0&&year%400==0)||(year%4==0&&year%100!=0))                                                    /*checks the required                                                     condition for leap year*/
     return 1;  //print if condition is true   
    else                     //print if condition is false
     return 0;
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#include<math.h>
int student_solution(int input_year)
{
 int a;a = input_year;;
 //scanf("%d",&a);
 if((a%100==0)&&(a%400==0))//reminder of both should be 0
 {
     return 1;//february of this year has 29 days 
     }
else if ((a%4==0)&&(a%100!=0)) 
 {
     return 1;
     }
 
 else
 {
     return 0;//february of this year has 28 days 
 }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int y;y = input_year;;
    //scanf("%d" ,&y);
    // to check whether a given year is leap tear or notleap year is            an year with 366 days rather than 365 days.
    
    if((y%4==0 && y%100!=0) || (y%100==0 && y%400==0))//criteria for leap                                                        year
        return 1;     
    else
        return 0;  
        
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{int yr;yr = input_year;;                   
 //scanf("%d",&yr);          
 if(yr%4==0){         //if1
   if(yr%100==0){     //if2
     if(yr%400==0)    //if3
       return 1;
     else              //else for if3
       return 0;}
   else                //else for if2
     return 1;}
 else                  //else for if1
   return 0;
 //return 0;
}
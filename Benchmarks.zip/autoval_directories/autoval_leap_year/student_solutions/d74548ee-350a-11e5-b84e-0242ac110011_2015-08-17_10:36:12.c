/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int y;y = input_year;;                /*y is year which is given as input*/
    int a,b,c;
    //scanf("%d",&y);
    a=y%4;
    b=y%100;
    c=y%400;
    
    if(a==0)              /*nested if-else*/
    {   if(b==0)
           {if(c==0)
              return 1;
            else
              return 0;
           }
        else
          return 1;
    }
    else
      return 0;
      
    
    //return 0;
}
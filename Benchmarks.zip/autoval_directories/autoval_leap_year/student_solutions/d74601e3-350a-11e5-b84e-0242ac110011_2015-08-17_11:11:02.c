/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
    /* prg to determine leap year */
int student_solution(int input_year)
{
    int year;year = input_year;;   /* deckaration of variable/s */
    //scanf("%d", &year);    /* input year */
    if(year%4||year<0)  /* testing non negativity condition*/
    {
        return 0;
    }
    else    /* testing condition for leap year*/
    {
        if(year%100)
        {
            return 1;
        }
        else
        {
            if(year%400)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
    }
    //return 0;
}
/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
//PROGRAM BEGINS
{
    int year;year = input_year;;
    int s = 4; //declaration
    //scanf("%d", &year);
    if(year/s){
        if((year/100)&(year/400)){
        return 1;
    }
}
    else {
        return 0;
        }

    //return 0;
    // PROGRAM ENDS
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int yearno;yearno = input_year;;//yearno takes the value of the year as input
    //scanf("%d", &yearno);
    if(((yearno%4 == 0) && (yearno%100 !=0)) || (yearno%400 == 0)){//Checking if yearno satisfies the conditions for a leap year
        return 1;
    }
    else{
        return 0;
    }
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int y;y = input_year;;
    //scanf("%d",&y);//taking input from user
    if(y%4==0)
    {if(y%100==0 && !(y%400==0))//applying condition
      return 0;
      else//nested looping
        return 1;//printing result
    }
    else
    return 0;
    //return 0;
}    
    
    // Fill this area with your code.
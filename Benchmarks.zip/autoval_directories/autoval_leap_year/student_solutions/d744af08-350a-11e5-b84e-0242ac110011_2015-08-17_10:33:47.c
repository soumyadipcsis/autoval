/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{ 
    int A;A = input_year;;
    //scanf("%d",&A);
    
    if(A%4==0)
    {
       if(A%100==0) 
       {
            if(A%400==0)
                return 1;
            else
                return 0;
       }
       else
            return 1;

    }
    else if (A%4!=0)
    {
        return 0;   
    }
    //return 0;
}
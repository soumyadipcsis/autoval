/*compile-errors:e156_271025.c:10:18: warning: expression result unused [-Wunused-value]
    else(a%100==0&&a%400==0);
         ~~~~~~~~^ ~~~~~~~~
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int a;a = input_year;;
    //scanf("%d",&a);
    if(a%4==0&&a%100&&a%400){
    if(a%4==0)
    return 1;
    else(a%100==0&&a%400==0);
    return 0;}
    else
    return 0;
    //return 0;
}

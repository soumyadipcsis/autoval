/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

 int student_solution(int input_year)  {
 int y;y = input_year;;  /* input variable;y*/
 //scanf("%d",&y);
 if(y%4==0){        //y is divisible by 4
     if(y%100==0){   //y is divisible by 100
        if(y%400==0){       //y is divisible by 400
            return 1;
        }
         else{              /* y is not divisible by 400*/
            return 0;
         }
    }else{
        return 1;//y is not divisible by
    }
     }
 else   
     return 0;
    //return 0;
}
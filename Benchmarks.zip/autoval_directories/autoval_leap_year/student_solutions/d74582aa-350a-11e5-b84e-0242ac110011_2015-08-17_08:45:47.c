/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    // Fill this area with your code.
    int a;a = input_year;;//takes year as input
    //scanf("%d",&a);
    
    if(a%100==0){//checks if divisible by hundred or not
        if(a%400==0)//checks divisibility by 400
            return 1;
        else
            return 0;
    }
    else if(a%4==0)//checks divisibility by 4
        return 1;
    else
        return 0;
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{   int year;year = input_year;;                           // year input by user
    //scanf("%d",&year);
    if (year%4 != 0){                   // year div. by 4 or not   
        return  0; }
    else {
        if (year%100 != 0){             // year div. by 100 or not
        return  1; }
        else {
            if (year%400 != 0){         // year div. by 400 or not 
                return 0; }
            else{
                return 1; }
        }
    }
    //return 0;
}
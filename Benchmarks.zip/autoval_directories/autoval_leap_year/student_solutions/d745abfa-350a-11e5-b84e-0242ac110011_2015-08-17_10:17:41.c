/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
 int b;b = input_year;;
 int a= 4;
 //scanf("%d",&b);
 if (b%a==0){
 return 1;}
 else {
 return 0;}// Fill this area with your code.
    //return 0;
}
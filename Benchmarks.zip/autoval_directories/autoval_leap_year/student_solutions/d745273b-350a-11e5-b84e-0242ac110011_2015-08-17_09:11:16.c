/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year){
    int year;year = input_year;;
    //scanf ("%d",&year);//input year
    
    if ((year%4==0 && year%'d'!=0)||(year%400==0))
    return 1;
    else
    return 0;
    /*leap years include multiples of 400 and years divisible by 4 but       not 100*/ 
   
    //return 0;
}
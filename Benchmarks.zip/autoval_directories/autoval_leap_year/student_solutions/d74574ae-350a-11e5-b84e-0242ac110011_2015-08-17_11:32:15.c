/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int Year;Year = input_year;;
    //scanf("%d",&Year);
    if (((Year%4==0)&&(Year%100!=0))||((Year%400==0)&&(Year%100==0))){
        return 1;//year is a leap year
    }
    else
    {
        return 0;//year is not a leap year
    }
    //return 0;
}
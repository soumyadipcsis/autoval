/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>//first made a flow chart
int student_solution(int input_year)
{
int a;a = input_year;;
    //scanf("%d",&a);//input a (leap year)
if(a%100==0) {//check for %100
    if(a%400==0){//if T check for %400
        return 1;
    }
    else{//if not 
    return 0;//direclty print not a leap year
    }
}
else{
    if(a%4==0){//simple leap year
        return 1;
    }
    else{// non leap year
        return 0;//printing "Not a Leap Year"
    }
}
    //return 0;
}
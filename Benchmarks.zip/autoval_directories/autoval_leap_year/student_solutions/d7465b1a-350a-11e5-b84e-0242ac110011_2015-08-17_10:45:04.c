/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    //Program to check whether a year is leap year or not
    
int y;y = input_year;;

//scanf("%d",&y); 

if(y%4==0) //Leap year is divisible by 4 
 {
    if(y%100==0) 
    {
        if(y%400==0) //If divisible by 100 then also be divisible by400
        return 1;
        
        else 
        return 0;
    }
    
    else
    return 1;
 }    
    
else
return 0;
    

    //return 0;
}
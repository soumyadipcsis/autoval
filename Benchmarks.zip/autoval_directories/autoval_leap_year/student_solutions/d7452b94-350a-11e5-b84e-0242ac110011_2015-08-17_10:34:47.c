/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int x;x = input_year;;          //it intakes the year which you want to check
    //scanf ("%d",&x);
    if(x%4==0)          //it checks if the year is leap or not because if it is divisible by 4 then it is leap year
    {
            if(x%100==0)    //it checks 2nd condition of leap year
                {
                    if(x%400==0)
                        {return 1;}
                    else
                        {return 0;}
                }
            else
                {return 1;}
    }
    else        //if the year is not a leap year then else statement is exicuted
    {
        return 0;
    }
    //return 0;
}
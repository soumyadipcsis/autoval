/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
     //program to determine whether year is leap year or not
int year;year = input_year;;
     //scanf("%d",&year);
     //divisibility by 4 is neccessary condition for year to be leap year
if (year%4==0){
    if (year%100==0){
        //special condition if the year is divisible by 100
        if (year%400==0){
            return 1;
        } else {
            return 0;
        }
    }
    else {
        return 1;
    }
}
else {
     return 0;
}
     //return 0;
}
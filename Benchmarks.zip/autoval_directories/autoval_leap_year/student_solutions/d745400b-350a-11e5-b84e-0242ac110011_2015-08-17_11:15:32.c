/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year){
    
    int a;a = input_year; ;
    //scanf("%d",&a);//read the year value
    
    if ((a%4==0) && (a%'d'!=0))//condition on 'a'
        
        return 1;
    else
        {
            if((a%4==0) && ((a%'d'==0) && (a%400==0)))//condition on a
            return 1;
            else
            return 0;//print the value
        }    
    //return 0;
}
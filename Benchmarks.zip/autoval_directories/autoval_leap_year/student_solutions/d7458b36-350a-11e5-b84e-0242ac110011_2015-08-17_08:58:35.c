/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int y;y = input_year;;     /*variable declaration*/
    //scanf("%d",&y);
    if(y%100==0)
    {
       if(y%400==0)
       {
           return 1;
       }else{     /*y%100!=0*/
           return 0;
       }
    }else{      /*y%100!=0*/
        if(y%4==0){
            return 1;
        }else{        /*y%4!=0*/
            return 0;
        }
    
    }
}
//return 0;}

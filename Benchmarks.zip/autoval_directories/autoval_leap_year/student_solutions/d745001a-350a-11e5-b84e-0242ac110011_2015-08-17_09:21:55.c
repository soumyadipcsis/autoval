/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int y;y = input_year;;/*y represents the year*/
    //scanf("%d",&y);/*& is used to specify the location*/
    if(y%4==0)//y is divisible by 4 
    {
        return 1;
    }
    else{
        return 0;
    }//y is not divisible by 4 
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int y;y = input_year;;//y as year
    //scanf("%d",&y);
    if (y%100==0 && y%400==0)//Leap Year,if y divisible by 100 & 400 both
       return 1;
    else
        if (y%4==0 && y%100!=0)//Leap Year,if y divisible just by 4
           return 1; 
        else
           return 0;
    //return 0;
}
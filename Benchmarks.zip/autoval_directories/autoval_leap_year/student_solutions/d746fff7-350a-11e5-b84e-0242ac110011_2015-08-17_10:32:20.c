/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int y;y = input_year;int k,g,h;       // years and leap year determiner variable
    //scanf("%d",&y);    // entering year
    k=y%4;                // divisibility test for leap years
    g=y%100;
    h=y%400;
    if(k==0)              // condition satisfy for leap year
    {
        return 1;
    }
    else
    {
        if(g==0)
        {
            return 1;
        }
        else
        {
            if(h==0)
            {
                return 1;
            }
            else
            {
            return 0;    
            }
        }
    }
    //return 0;
}

/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>

int student_solution(int input_year)
{
    int a;a = input_year;;//year
    //scanf("%d",&a);//get values from user
    if(a%100==0 & a%400==0){
    return 1;  //if year is divisible by 100 also divisible by 4 then it is leap year
    }
    else if(a%100==0 & a%400!=0){
        return 0;//if year is divisible by 100 and not divisible by 400 then not a leap year
    }
    else if(a%100!=0 & a%4==0){
        return 1;//if year is not divisible by 100 and divisible by 4 then it is leap year
    }
    else if(a%100!=0 & a%4!=0){
        return 0;//if a is not divisible by 100 also not divisible by 100 then it is not leap year
    }
    //return 0;
}
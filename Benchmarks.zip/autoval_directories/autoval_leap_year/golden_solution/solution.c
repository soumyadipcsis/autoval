#include<stdio.h>

int golden_solution(int input_year)
{
	int y;
	y=input_year;
	//scanf("%d", &y);
	if(y % 4 == 0)
	{
		if(y % 100 == 0)
		{
			if(y % 400 == 0)
				return 1;
			else
				return 0;
		}
		else
			return 1;
	}
	else
		return 0;	
}
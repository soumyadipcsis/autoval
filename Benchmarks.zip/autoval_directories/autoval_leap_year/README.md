# Project Autoval
A CLI Tool for automatically evaluating student code submissions

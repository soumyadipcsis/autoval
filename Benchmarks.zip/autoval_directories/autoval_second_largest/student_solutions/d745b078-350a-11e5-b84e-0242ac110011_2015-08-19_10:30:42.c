/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d,temp;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    //arranging numbers in a order such that a < b < c < d
    if(b<a)                     //comparing a and b
    {   temp=a;                 //swapping a and b
        a=b;
        b=temp;
    }
    if(c<b)                     //comparing c and b
    {   
        temp=c;                 //swapping b and c
        c=b;
        b=temp;    
            if(b<a)             //comparing a and b
            {   temp=a;         //swapping a and b
                a=b;
                b=temp;
            }    
    }
    if(d<c)                     //comparing c and d
    {   temp=d;                 //swapping c and d
        d=c;
        c=temp;
        if(c<b)                 //comparing b and c
        {                       
            temp=c;             //swapping b and c
            c=b;
            b=temp;    
            if(b<a)             //comparing a and b
            {   temp=a;         //swapping a and b 
                a=b;
                b=temp;
            }
        }
    }
    //In order a<b<c<d, c is the second largest number
    return("The second largest number is %d",c);
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a; //initialising variable a//

    int b;//initialising vaiable b//
    
    int c;//initialising variable c//
    
    int d;//initialising variable d//
    scanf("%d" "%d" "%d" "%d",&a,&b,&c,&d);
    if(b>c && c>a && c>d){
        return("The second largest number is %d",c);
    }//condition for c to be 2nd largest when b is largest//
      else if(b>a && a>c && a>d){
          return("The second largest number is %d",a);
      }//condition for a to be 2nd largest when b is largest//
      else if(a>b && b>c && b>d){
          return("The second largest number is %d",b);
      }//condition for b to be 2nd largest when a is largest//
      else if(d>c && c>b && c>a){
          return("The second largest number is %d",c);
      } //condition for c to be 2nd largest when d is largest//
      else if(d>a && a>c && a>b ){
          return("The second largest number is %d",a);
      }//condition for a to be 2nd largest when d is largest//
      else if(b>c && c>a && c>d){
          return("The second largest number is %d",c);
      }//condition for c to be 2nd largest when b is largest//
      else if(a>c && c>b && c>d){
          return("The second largest number is %d",c);
      }//condition for c to be 2nd largest when a is largest//
      else if(c>a && a>b && a>d){
          return("The second largest number is %d",a);
      }//condition for a to be 2nd largest when c is largest//
      else if(c>b && b>d && b>a){
          return("The second largest number is %d",b);
      }
      //condition for b to be 2nd largest when c is largest//
      else if(d>b && b>a && b>c){
          return("The second largest number is %d",b);
          
      } //condition for b to be 2nd largest when d is largest//
      else {
          return("The second largest number is %d",d);
      }// condition for d to be 2nd largest when a or b or c are the largest//
      
      
      
          
    
    

    //return 0;
}
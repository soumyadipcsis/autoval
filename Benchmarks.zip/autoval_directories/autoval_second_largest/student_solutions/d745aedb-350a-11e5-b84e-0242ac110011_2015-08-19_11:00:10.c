/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;
int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    if ((a>b)&&(a>c)&&(a>d)){if((b>c)&&(b>d)){return("The second largest number is %d",b);}else{if(c>d){printf("%d",c);}else{printf("The second largest number is %d",d);}}}/*a is the largest*/
    if ((b>a)&&(b>c)&&(b>d)){if((a>c)&&(a>d)){return("%d",a);}else{if(c>d){printf("The second largest number is %d",c);}else{printf("The second largest number is %d",d);}}}  /*b is the largest*/  
    if ((c>b)&&(c>a)&&(c>d)){if((b>a)&&(b>d)){return("The second largest number is %d",b);}else{if(a>d){printf("The second largest number is %d",a);}else{printf("The second largest number is %d",d);}}}/*c is the largest*/
    if ((d>b)&&(d>c)&&(d>a)){if((b>c)&&(b>a)){return("The second largest number is %d",b);}else{if(c>a){printf("The second largest number is %d",c);}else{printf("The second largest number is %d",a);}}}/*d is the largest*/
    
    
    //return 0;
}
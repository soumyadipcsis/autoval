/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
 int a,b,c,d;
 scanf("%d%d%d%d",&a,&b,&c,&d);
  if((a>=b)&&(a>=c)&&(a>=d)){// a being the largest
    if((b>=c)&&(b>=d)){return("The second largest number is %d",b);}
    else if (c>=d){return("The second largest number is %d",c);}
    else {return("The second largest number is %d",d);}}
  if((b>=a)&&(b>=c)&&(b>=d)){//b being the largest
    if((a>=c)&&(a>=d)){return("The second largest number is %d",a);}
    else if (c>=d){return("The second largest number is %d",c);}
    else {return("The second largest number is %d",d);}}
  if((c>=b)&&(c>=a)&&(c>=d)){//c being the largest
    if((b>=a)&&(b>=d)){return("The second largest number is %d",b);}
    else if (a>=d){return("The second largest number is %d",a);}
    else {return("The second largest number is %d",d);}}
  if((d>=b)&&(d>=a)&&(d>=c)){//d being the largest
    if((b>=a)&&(b>=c)){return("The second largest number is %d",b);}
    else if (a>=c){return("The second largest number is %d",a);}
    else {return("The second largest number is %d",c);}}
    //return 0;}
}

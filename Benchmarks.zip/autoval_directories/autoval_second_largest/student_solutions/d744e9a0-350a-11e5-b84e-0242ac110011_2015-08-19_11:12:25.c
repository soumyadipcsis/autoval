/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d;        /*declaration of 4 numbers*/
    scanf("%d%d%d%d",&a,&b,&c,&d);
             


    if((a>b)&&(b>c)&&(c>d))
            {
              return("The second largest number is %d",b);
 
             }
    else if((b>c)&&(c>d)&&(d>a))
        {
            return("The second largest number is %d",c);
            
        }
    else if((c>d)&&(d>a)&&(a>b))
        {
            return("The second largest number is %d",d);
            
        }
    else if((d>a)&&(a>b)&&(b>c))
        {
            return("The second largest number is %d",a);
            
        }
        
        
        
    else if((a>b)&&(b>d)&&(d>c))
        {
            return("The second largest number is %d",b);
            
        }
    else if((b>d)&&(d>c)&&(c>a))
        {
            return("The second largest number is %d",d);
            
        }
    else if((d>c)&&(c>a)&&(a>b))
        {
            return("The second largest number is %d",c);
            
        }
    else if((c>a)&&(a>b)&&(b>d))
        {
            return("The second largest number is %d",a);
            
        }
        
        
        
    else if((a>c)&&(c>b)&&(b>d))
        {
            return("The second largest number is %d",c);
            
        }
    else if((c>b)&&(b>d)&&(d>a))
        {
            return("The second largest number is %d",b);
            
        }
    else if((b>d)&&(d>a)&&(a>c))
        {
            return("The second largest number is %d",d);
            
        }
    else if((d>a)&&(a>c)&&(c>b))
        {
            return("The second largest number is %d",a);
            
        }
        
        
        
        
    else if((a>c)&&(c>d)&&(d>b))
        {
            return("The second largest number is %d",c);
            
        }
    else if((c>d)&&(d>b)&&(b>a))
        {
            return("The second largest number is %d",d);
            
        }
    else if((d>b)&&(b>a)&&(a>c))
        {
            return("The second largest number is %d",b);
            
        }
    else if((b>a)&&(a>c)&&(c>d))
        {
            return("The second largest number is %d",a);
            
        } 
    else if(a==b==c==d)
    {
        return("The second largest number is %d",a);
    }
                     
                     
                     
                     
    else
        {
            return("wrong input");
        }
    
    //return 0;
}
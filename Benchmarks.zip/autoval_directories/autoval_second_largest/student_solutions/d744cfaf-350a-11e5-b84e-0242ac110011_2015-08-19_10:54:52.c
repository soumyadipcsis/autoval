/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int m;
    int a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    if(a>b && b>c && c>d){
        m=b;
    }
    else if(a>b && b>d && d>c){
        m=b;
    }
    else if(a>c && c>b && b>d){
        m=c;
    }
    else if(a>d && d>c && c>b){
        m=d;
    }
    else if(a>d && d>b && b>c){
        m=d;
    }
    else if(a>c && c>d && d>b){
        m=c;
    }
    else if(c>a && a>b && b>d){
        m=a;
    }
    else if(c>a && a>d && d>b){
        m=a;
    }
    else if(c>d && d>a && a>b){
        m=d;
    }
    else if(c>d && d>b && b>a){
        m=d;
    }
    else if(c>b && b>a && a>d){
        m=b;
    }
    else if(c>b && b>d && d>a){
        m=b;
    }
    else if(d>a && a>b && b>c){
        m=a;
    }
    else if(d>a && a>c && c>b){
        m=a;
    }
    else if(d>c && c>a && a>b){
        m=c;
    }
    else if(d>c && c>b && b>a){
        m=c;
    }
    else if(d>b && b>c && c>a){
        m=d;
    }
    else if(d>b && b>a && a>c){
        m=b;
    }
    else if(b>a && a>c && c>d){
        m=a;
    }
    else if(b>a && a>d && d>c){
        m=a;
    }
    else if(b>d && d>a && a>c){
        m=d;
    }
    else if(b>d && d>c && c>a){
        m=d;
    }
    else if(b>c && c>a && a>d){
        m=c;
    }
    else{
        m=c;
    }
        return("The second largest number is %d",m);
    // Fill this area with your code.
    //return 0;
}
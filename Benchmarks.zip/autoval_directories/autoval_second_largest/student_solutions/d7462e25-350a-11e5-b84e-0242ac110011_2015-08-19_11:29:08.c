/*compile-errors:e156_271592.c:6:18: warning: incomplete format specifier [-Wformat]
    scanf("%d%d%d%",&n1,&n2,&n3,&n4);
                 ^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int n1,n2,n3,n4;
    scanf("%d%d%d%",&n1,&n2,&n3,&n4);
    if((((n1>n2)&&(n2>n3)&&(n3>n4))||((n3>n2)&&(n2>n1)&&(n2>n4))||((n4>n2)&&(n2>n1)&&(n2>n3)))==1) {
        return("%d",n2);
    }
    
    //return 0;
}

/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d ;
    scanf("%d%d%d%d",&a,&b,&c,&d);
   
    if(b>=c&&b>=a&&b>=d&&a>=c&&a>=d)
    {    
        return("The second largest number is %d",a );
        //return 0 ;
    }
    if(b>=c&&b>=a&&b>=d&&c>=a&&c>=d)
    {
        return("The second largest number is %d", c);
        //return 0 ;
    }
    if(b>=c&&b>=a&&b>=d&&d>=a&&d>=c)
    {   
        return("The second largest number is %d", d);
        //return 0 ;
    }
    if(c>=a&&c>=b&&c>=d&&a>=b&&a>=d)
    {
        return("The second largest number is %d", a);
        //return 0 ;
    }
    if(c>=a&&c>=b&&c>=d&&b>=a&&b>=d)
    {
        return("The second largest number is %d", b);
        //return 0 ;
    }
    if(c>=a&&c>=b&&c>=d&&d>=a&&d>=b)
    {
        return("The second largest number is %d", d);
        //return 0 ;
    }
    if(d>=a&&d>=b&&d>=c&&a>=b&&a>=c)
    {
        return("The second largest number is %d", a);
        //return 0 ;
    } 
    if(d>=a&&d>=b&&d>=c&&b>=a&&b>=c)
    {
        return("The second largest number is %d", b);
        //return 0 ;
    }
    if(d>=a&&d>=b&&d>=c&&c>=a&&c>=b)
    {
        return("The second largest number is %d", c);
    }
      if(a>=b&&a>=c&&a>=d&&b>=c&&b>=d)
    {
        return("The second largest number is %d",b );
        //return 0 ;
    }
    if(a>=b&&a>=c&&a>=d&&c>=b&&c>=d)
    {
        return("The second largest number is %d", c);
        //return 0 ;
    }
    if(a>=b&&a>=c&&a>=d&&d>=b&&d>=c)
    {
        return("The second largest number is %d", d);
        //return 0 ;
    }
        //return 0 ;
        
        
    
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a;int b;int c;int d;
    scanf ("%d %d %d %d",&a,&b,&c,&d);// taking input
    if ((a<=b && a>=c && a>=d) || (a<=c && a>=b && a>=d) || (a<=d && a>=b && a>=c)){
     return("The second largest number is %d",a);//a will get printed
     }
     else if ((b<=a && b>=c && b>=d) || (b<=c && b>=a && b>=d) || (b<=d && b>=a && b>=c)) { return("The second largest number is %d",b);//b will get printed
     }
     else if ((c<=a && c>=b && c>=d) || (c<=b && c>=a && c>=d) || (c<=d && c>=a && c>=b)) { return("The second largest number is %d",c);//c will get printed
       }
    else if ((d<=a && d>=b && d>=c) || (d<=b && d>=a && d>=c) || (d<=c && d>=a && d>=b)) { return("The second largest number is %d",d);//d will get printed
     }
    
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d;
    scanf("%d %d %d %d", &a,&b,&c,&d);// a,b,c,d are 4 natural numbers//
    if(a<c && b<c && c<d)return("The second largest number is %d",c);//First condition for c to be second largest//
    else if(a>c && c<b && c<d)return("The second largest number is %d",c);//Second condition for c to be second largest//
    else if (b>c && a<c && d<c)return("The second largest number is %d",c);//Third condition for c to be second largest//
    else if (a>b && a>c && a<d)return("The second largest number is %d ",a);//First condition for a to be second largest//
    else if (a<b && a>c && a>d)return("The second largest number is %d",a);//Second condition for a to be second largest//
    else if (a<c && a>b && a>d)return("The second largest number is %d",a);//Third condition for a to be second largest//
    else if (b<a && b>c && b>d)return("The second largest number is %d",b);//First condition for b to be second largest //
    else if (b<c && b>a && b>d)return("The second largest number is %d",b);//Second condition for a to be seccond largest//
    else if (b<d && b>a && b>c)return("The second largest number is %d",b);//Third condition for a to be second largest//
    else return("The second largest number is %d",d);


    
    //return 0;
}
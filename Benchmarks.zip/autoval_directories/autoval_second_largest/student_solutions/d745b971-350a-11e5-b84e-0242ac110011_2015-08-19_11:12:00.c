/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;
int student_solution(int input_a, int input_b, int input_c, int input_d)
{int a,b,c,d;
scanf("%d%d%d%d",&a,&b,&c,&d);
if(a<=b)
{
    if(b>=c)
    {                             
          if(c>=d)
          {
              if(b>=d){
                  return("The second largest number is %d",c);
          }          
          }
    }
}    
 if(b>=a)
 {
     if(a>=c)
     {
      if(a>=d)
      {
          if(b>=d){
    return("The second largest number is %d",a);
    }
      }
     }
 }
    if(a>=d)
    {
   if(d>=c)
   {
       if(d>=b)
       {
           if(a>=c){
               if(a>=b){
           return("The second largest number is %d",d);
       }
           }
   }
    }
}
       if(c>=b)
       {
           if(b>=a)
           {
               if(b>=d)
               {
                   if(c>=a){
                       if(c>=d){
                   return("The second largest number is %d",b);
       }
                   }
               }
         }
       }
    //return 0;
}
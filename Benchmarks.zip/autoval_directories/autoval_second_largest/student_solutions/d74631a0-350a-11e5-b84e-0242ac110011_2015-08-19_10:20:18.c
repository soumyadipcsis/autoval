/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
/* This program will print the second largest among four numbers. */

#include <stdio.h>

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a1,a2,a3,a4,x=0; //variables to store numbers
    //x stores second largest number
    scanf("%d %d %d %d", &a1,&a2,&a3,&a4); //accepting input
    if (a1>a2 && a1>a3 && a1>a4) //if a1 is largest
    {
        if (a2>a3 && a2>a4)
        x=a2;
        else if (a3>a2&&a3>a4)
        x=a3;
        else
        x=a4;
    }
    if (a2>a1 && a2>a3 && a2>a4) //if a2 is largest
    {
        if (a1>a3 && a1>a4)
        x=a1;
        else if (a3>a1&&a3>a4)
        x=a3;
        else
        x=a4;
    }
    if (a3>a1 && a3>a4 && a3>a2) //if a3 is largest
    {
        if (a2>a4 && a2>a1)
        x=a2;
        else if (a4>a2&&a4>a1)
        x=a4;
        else
        x=a1;
    }
    if (a4>a1 && a4>a2 && a4>a3) //if a4 is largest
    {
        if (a2>a3 && a2>a1)
        x=a2;
        else if (a3>a1&&a3>a2)
        x=a3;
        else
        x=a1;
    }
    //following four cases, if any two inputs are equal:
    if (a1==a2)
    {
        if (a1>a3&&a1>a4)
        x=a1;
        else
        {
            if (a3>a4)
            x=a3;
            else
            x=a4;
        }
    }
    if (a2==a3)
    {
        if (a2>a4&&a2>a1)
        x=a2;
        else
        {
            if (a4>a1)
            x=a4;
            else
            x=a1;
        }
    }
    if (a3==a4)
    {
        if (a3>a1&&a3>a2)
        x=a3;
        else
        {
            if (a1>a2)
            x=a1;
            else
            x=a2;
        }

    }
    if (a4==a1)
    {
        if (a4>a2&&a4>a3)
        x=a4;
        else
        {
            if (a2>a3)
            x=a2;
            else
            x=a3;
        }
    }
    //following test cases, if three inputs are equal:
    if (a1==a2 && a2==a3)
    {
        if (a1>a4)
        x=a4;
        else
        x=a1;
    }
    if (a1==a2 && a2==a4)
    {
        if (a1>a3)
        x=a3;
        else
        x=a1;
    }
    if (a1==a3 && a3==a4)
    {
        if (a1>a4)
        x=a4;
        else
        x=a1;
    }
    if (a2==a3 && a3==a4)
    {
        if (a1>a2)
        x=a2;
        else
        x=a1;
    }
    if (a1==a2 && a2==a3 && a3==a4) //if all inputs are equal
    x=a1;
    return("The second largest number is %d", x); //output
    //return 0;
}
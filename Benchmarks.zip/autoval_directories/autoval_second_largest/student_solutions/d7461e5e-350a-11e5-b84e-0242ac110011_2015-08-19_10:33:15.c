/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d,m1,l1,m2,l2,res;    //res is to store 2nd largest no.
    scanf("%d %d %d %d",&a,&b,&c,&d);
    if(a>b){
            m1=a;       //m1 is for maximum of these two
            l1=b;       //l1 is for lower of these two
            }
    else{
           m1=b;
           l1=a;
           }
    if(c>d){
            m2=c;
            l2=d;
            }
    else {
            m2=d;
            l2=c;
           }
    if(m1>m2){
             if(m2>l1)
                    res=m2;
             else
                    res=l1;
              }
    else{
             if(m1>l2)
                    res=m1;
             else
                    res=l2;
           }            
    return("The second largest number is %d",res);
    //return 0;
}
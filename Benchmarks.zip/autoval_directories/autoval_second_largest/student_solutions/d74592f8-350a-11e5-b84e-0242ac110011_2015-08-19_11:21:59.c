/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d,p,q,r,s;//creating some extra boxes and input boxes
    scanf("%d %d %d %d",&a,&b,&c,&d);//taking input
        if(a>=b)//comparing among a and b assigning to p the greater                     value
                //the other value to q
          {p=a;q=b;}
        else
          {p=b;q=a;}
        if(c>=d)//comparing among c and d assigning to r the larger                      value 
                //the other value to s
          {r=c;s=d;}
        else
          {r=d;s=c;}
    if(p>r)//comparing p and r
           //using multiple if else statements to find the second                   largest number 
       {if(q>r)
         {return("The second largest number is %d",q);}//printing ans
       else
         {return("The second largest number is %d",r);}}//printing ans
    else
       {if(s>p)
         {return("The second largest number is %d",s);}//printing ans
       else
         {return("The second largest number is %d",p);}}//printing ans
    
    
    //return 0;
}
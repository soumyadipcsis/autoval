/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{ int max,max2,a,b,c,d;
scanf("%d %d %d %d",&a,&b,&c,&d);
max=a;
if(b>max)
{max=b;}
else if(c>max)
{max=c;}
else if(d>max)
{max=d;}

if (max==a){
    max2=b;
    if(c>max2)
    {max2=c;}
else if(d>max2)
{max2=d;}

return("%d",max2);
    
}
 if (max==b){
    max2=a;
    if(c>max2)
    {max2=c;}
else if(d>max2)
{max2=d;}

return("%d",max2);
    
}
if (max==c){
    max2=a;
    if(b>max2)
    {max2=b;}
else if(d>max2)
{max2=d;}
return("%d",max2);}
if (max==d){
    max2=a;
    if(b>max2)
    {max2=b;}
else if(c>max2)
{max2=c;}

return("The second largest number is %d",max2);}
//return 0;
}
/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;
int student_solution(int input_a, int input_b, int input_c, int input_d){
    int a,b,c,d,e;
    scanf("%d %d %d %d",&a,&b,&c,&d);//input four numbers
    if(a>b){
        if(b>c){
            if(c>d){//a>b>c>d
                e=b;
            }
            else if(b>d){//a>b>d>c
                e=b;
            }
                else if(a>d){//a>d>b>c
                e=d;
            }
                    else{//d>a>b>c
                e=a;
            }
        }
        else{
            if(a>c){
                if(c>d){//a>c>b and c>d
                    e=c;
                }
                else if(a>d){//a>d>c>b
                    e=d;
                }
                    else{//d>a>c>b
                        e=a;
                    }
                }
            else if(a>d){//c>a>b and a>d
                e=a;
            }
                else if(c>d){//c>d>a>b
                e=d;
            }
                    else{//d>c>a>b
                    e=c;
                    }
            }
            }
    else{
        if(a>c){
            if(c>d){//b>a>c>d
                e=a;
            }
            else if(a>d){//b>a>d>c
                e=a;
            }
                else if(b>d){//b>d>a>c
                    e=d;
                }
                    else{//d>b>a>C
                        e=b;
                    }   
        }
        else{
            if(b>c){
                if(c>d){//b>c>d and c>a
                    e=c;
                }
                else if(b>d){//b>d>c>a
                    e=d;
                }
                    else{//d>b>c>a
                    e=b;
                    }
                }
            else if(b>d){//c>b>d and b>a
                e=b;
            }
                else if(c>d){//c>d>b>a
                    e=d;
                }
                    else{//d>c>b>a
                        e=c;
                    }
            }
            }
    return("The second largest number is %d",e);//ouput the answer
    //return 0;
}
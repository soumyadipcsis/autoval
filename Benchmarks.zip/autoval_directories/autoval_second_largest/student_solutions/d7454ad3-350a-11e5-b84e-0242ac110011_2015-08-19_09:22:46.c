/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d,r;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    //Our motive is to arrange the 4 numbers in decreasing order
    
    for(int i=1;i<=3;i++) // Repeat the following procedure 3 times
    {
        if(a<b) // if a<b, then interchange the 2 numbers
        {
            r=a;a=b;b=r; 
        }
        if(b<c) // if b<c, then interchange the 2 numbers
        {
            r=b;b=c;c=r;
        }
        if(c<d) // if c<d, then interchange the 2 numbers
        {
            r=c;c=d;d=r;
        }
    /*Since after 1 round of swaping of 2 consecutive numbers
    We did NOT get a PERFECT decreasing sequence
    Hence some more rounds of swapping of numbers are needed
    Thats why we used FOR LOOP, for atleast 3 times*/
    }
    return("The second largest number is %d",b);
}
/*compile-errors:e156_271613.c:5:10: warning: invalid conversion specifier ',' [-Wformat-invalid-specifier]
 scanf("%,d,%,d",&a,&b,&c);
        ~^
e156_271613.c:5:14: warning: invalid conversion specifier ',' [-Wformat-invalid-specifier]
 scanf("%,d,%,d",&a,&b,&c);
          ~~~^
e156_271613.c:5:24: warning: data argument not used by format string [-Wformat-extra-args]
 scanf("%,d,%,d",&a,&b,&c);
       ~~~~~~~~~       ^
e156_271613.c:9:11: warning: invalid conversion specifier 'T' [-Wformat-invalid-specifier]
 return("%The second largest number is 5");
         ~^
4 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d){
 int a,b,c;
 scanf("%,d,%,d",&a,&b,&c);
 return("%d",a);
 return("%d",b);
 return("%d",c);
 return("%The second largest number is 5");
 
    //return 0;
}
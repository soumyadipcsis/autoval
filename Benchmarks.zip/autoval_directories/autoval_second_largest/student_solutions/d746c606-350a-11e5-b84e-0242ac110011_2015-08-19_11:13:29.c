/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d;
    scanf("%d%d%d%d",&a,&b,&c,&d);
    if(a>b && a>c && a>d && b>c && b>d && c>d){
        return("%d",b);
    }
    if(a>b && a>d && a>c && b>d && b>c && d>c){
        return("%d",b);
    }
    if(a>c && a>b && a>d && c>b && c>d && b>d){
        return("%d",c);
    }
    if(a>c && a>d && a>b && c>d && c>b && d>b){
        return("%d",c);
    }
    if(a>d && a>b && a>c && d>b && d>c && b>c){
        return("%d",d);
    }
    if(a>d && a>c && a>b && d>c && d>b && c>b){
        return("%d",d);
    }
    if(b>a && b>d && b>c && a>d && a>c && d>c){
        return("%d",a);
    }
    if(b>a && b>c && b>d && a>c && a>d && c>d){
        return("%d",a);
    }
    if(b>c && b>a && b>d && c>a && c>d && a>d){
        return("%d",c);
    }
    if(b>c && b>d && b>a && c>d && c>a && d>a){
        return("%d",c);
    }    
    if(c>a && c>b && c>d && a>b && a>d && b>d){
        return("%d",a);
    }
    if(c>a && c>d && c>b && a>b && a>d && d>b){
        return("%d",a);
    }
    if(c>b && c>a && c>d && b>a && a>d && b>d){
        return("%d",b);
    }
    if(c>b && c>d && c>a && b>d && b>a && d>a){
        return("%d",b);
    }
    if(d>a && d>b && d>c && a>b && a>c && b>c){
        return("%d",a);
    }
    if(d>a && d>c && d>b && a>c && a>b && c>b){
        return("%d",a);
    }
    if(d>b && d>a && d>c && b>a  && b>c && a>c){
        return("%d",b);
    }
    if(d>b && d>c && d>a && b>c && b>a && c>a){
        return("%d",b);
    }
    if(d>c && d>a && d>b && c>a && c>b && a>b){
        return("%d",c);
    }
    if(d>c && d>b && d>a && c>b && b>a && c>a){
        return("%d",c);
    }
    if(b>d && b>a && b>c && d>a && d>c && a>c){
        return("%d",d);
    }
    if(b>d && b>c && b>a && d>c && d>a && c>a){
        return("%d",d);
    }
    if(c>d && c>a && c>b && d>a && d>b && a>b){
        return("%d",d);
    }
    if(c>d && c>b && c>a && d>b && d>a && b>a){
        return("%d",d);
    }    
    // Fill this area with your code.
    //return 0;
}

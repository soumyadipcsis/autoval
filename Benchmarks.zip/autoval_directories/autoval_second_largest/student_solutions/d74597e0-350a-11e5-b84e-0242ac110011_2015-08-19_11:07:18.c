/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
int a,b,c,d;
scanf("%d%d%d%d",&a,&b,&c,&d);
if(a>b)
{
    if(b>c)
    {if(d<a)
    {return("The second largest number is %d",b);}
else{return("the second lagest number is %d",d);}}
else
{if (c>d)
{return("the second largest number  is %d",c);}
else{return("the second largest number is %d",c);}
}}
else{
{if (b>c)
{if  (d<a)
{return("The second largest number is %d",b);}
else
{return ("The second largest number is %d",b);}}
else
{return ("the second largest number is %d",a);}
}
}

    //return 0;
}
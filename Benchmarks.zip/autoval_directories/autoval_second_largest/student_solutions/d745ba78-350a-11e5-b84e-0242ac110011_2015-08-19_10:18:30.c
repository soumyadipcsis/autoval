/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{  int a,b,c,d;                        //inititaion of variables
    scanf("%d %d %d %d",&a,&b,&c,&d);     //input taking
   int sl;
    if(a>b&&a>c&&a>d)
      { if(b>c&&b>d)
           sl=b;
        else if(c>b&&c>d)
           sl=c;
        else 
           sl=d;
      }
     if(b>c&&b>a&&b>d)
      { if(a>c&&a>d)
           sl=a;
        else if(c>a&&c>d)
           sl=c;
        else 
           sl=d;
      }  
     if(c>b&&c>a&&c>d)
      { if(b>a&&b>d)
           sl=b;
        else if(a>b&&a>d)
           sl=a;
        else 
           sl=d;
      }  
     if(d>b&&d>c&&d>a)
      { if(b>c&&b>a)
           sl=b;
        else if(c>b&&c>a)
           sl=c;
        else 
           sl=a;
      }  
      return("The second largest number is %d",sl);
        //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    // Fill this area with your code.
    int a,b,c,d;
    scanf("%d%d%d",&a,&b,&c,&d);
    if(a<b){if(c<b){if(a<c){if(d>c){return("The second largest number is %d",c);}else{printf("The second largest number is %d",d);} } else{if(d<a){printf("The second largest number is %d",a);}else{printf("The second largest number is %d",d);}}}else{if(d<a){printf("The second largest number is %d",a);}else{if(d<b){printf("The second largest number is %d",d);}else{printf("The second largest number is %d",b);}}}}else{if(c<a){if(d<b){printf("The second largest number is %d",b);}else{if(a>d){printf("The second largest number is %d",d);}else{printf("The second largest number is %d",a);}}}else{if(d<a){printf("The second largest number is %d",a);}else{if(c<d){printf("The second largest number is %d",c);}else{printf("The second largest number is %d",d);}}}}
                  
          
            
    
    //return 0;
}

/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{   int a,b,c,d;
    scanf("%d%d%d%d",&a,&b,&c,&d); // a,b,c,d are intiger//
    if (a>=b && a>=c && a>=d){ /*a>=b,a>=c and a>=d */
        if (b>=c && b>=d) // b>=c and b>=d so second largest number b//
            return("The second largest number is %d \n",b);
        else if (c>=b && c>=d) 
            return("The second largest number is %d \n",c);
        else if (d>=b && d>=c)
            return("The second largest number is %d \n",d);
    }
    else if (b>=a && b>=c && b>=d){ /*b>a,b>c and b>d */
         if (a>=c && a>=d)
           return("The second largest number is %d \n",a);
        else if (c>=a && c>=d)
           return("The second largest number is %d \n",c);
        else if (d>=c && d>=a)
           return("The second largest number is %d \n",d);
    }
    else if (c>=a && c>=b && c>=d){ /*c>a,c>b and c>d*/
         if (d>=a && d>=b)
           return("The second largest number is %d \n",d);
        else if (a>=b && a>=d)
           return("The second largest number is %d \n",a);
        else if (b>=a && b>=d)
           return("The second largest number is %d \n",b);
    }
    else if (d>=a && d>=b && d>=c){ /*d>a,d>b and d>c */
         if (c>=a && c>=b)
           return("The second largest number is %d \n",c);
        else if (a>=c && a>=b)
           return("The second largest number is %d \n",a);
        else if (b>=a && b>=c)
           return("The second largest number is %d \n",b);
            }
    // Fill this area with your code.
    //return 0;
}
/*execute-result:OK*/
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int n1,n2,n3,n4;              // 4 Natural numbers
    scanf("%d%d%d%d",&n1,&n2,&n3,&n4);// values of 4 numbers from user
    
    if((n1>=n2)&&(n1>=n3)&&(n1<=n4))//for n1 II largest  
        return("The second largest number is %d",n1);
    else if((n1>=n2)&&(n1<=n3)&&(n1>=n4))//for n1 II largest          
        return("The second largest number is %d",n1);  
    else if((n1<=n2)&&(n1>=n3)&&(n1>=n4))//for n1 II largest
        return("The second largest number is %d",n1);
    
    else if((n2>=n1)&&(n2>=n3)&&(n2<=n4))//for n2 II largest
        return("The second largest number is %d",n2);
    else if((n2>=n1)&&(n2<=n3)&&(n2>=4))//for n2 II largest
        return("The second largest number is %d",n2);
    else if((n2<=n1)&&(n2>=n3)&&(n2>=n4))//for n2 II largest
        return("The second largest number is %d",n2);
    
    else if((n3>=n1)&&(n3>=n2)&&(n3<=n4))//for n3 II largest
        return("The second largest number is %d",n3);
    else if((n3>=n1)&&(n3<=n2)&&(n3>=n4))//for n3 II largest
        return("The second largest number is %d",n3);
    else if((n3<=n1)&&(n3>=n2)&&(n3>=n4))//for n3 II largest
        return("The second largest number is %d",n3);
        
    else
        return("The second largest number is %d",n4);//for n4 II                                                             largest
    //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    // Fill this area with your code.

    int a,b,c,d;
    scanf("%d%d%d",&a,&b,&c,&d);
    //declare the four numbers of type int
    int large1,large2,large3;/*declaring three temporary variable where                                large2 store second largest no,large1                                  the largest and large3 the third                                       largest*/
    //nested if else statement
    if(a>b)                   //to assign a,b to large1 and large 2
    {
        large1=a;
        large2=b;
    }
    else
    {
        large1=b;
        large2=a;
    }         //input c
    //nested if else statement
    if(c>large2)            //to assign a,b,c as large1,large2,large3
    {
        if(c>large1)
        {
                large3=large2;
                large2=large1;
                large1=c;
        }
        else
        {
                large3=large2;
                large2=c;
        }
    }
    else
    {
        large3=c;
    }
    //nested if else statement
    if(d>large2)            //compare and assign second largest number
    {
        if(d>large1)
        {
            large2=large1;
        }
        else
        {
            large2=d;
        }
    }
    return("The second largest number is %d",large2);/*to print second                                                        largest number*/
    
    //return 0;
}

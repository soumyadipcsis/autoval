/*compile-errors:e156_271601.c:74:16: warning: variable 'rn' is used uninitialized whenever 'if' condition is false [-Wsometimes-uninitialized]
            if(a>=c)
               ^~~~
e156_271601.c:92:46: note: uninitialized use occurs here
    return("The second largest number is %d",rn);/* printing the output */
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d,rn;/* declaring variables */
    scanf("%d%d%d%d",&a,&b,&c,&d);/* taking input */
    if(a>=b&&a>=c&&a>=d)/* checking if a is largest */
    {
        if(b>=c)/* finding the largest among b,c,d */
        {
            if(b>=d)
            {
                rn=b;
            }
        }
        else
        {
            if(c>=d)
            {
                rn=c;
            }
            else
            {
                rn=d;
            }
        }
    }
    else if(b>=a&&b>=c&&b>=d)/* checking if b is the largest */
    {
        if(a>=c)/* finding the largest among a,c,d */
        {
            if(a>=d)
            {
                rn=a;
            }
        }
        else
        {
            if(c>=d)
            {
                rn=c;
            }
            else
            {
                rn=d;
            }
        }
    }
    else if(c>=a&&c>=b&&c>=d)/* checking if c is the largest */
    {
        if(a>=b)/* finding the largest among a,b,d */
        {
            if(a>=d)
            {
                rn=a;
            }
        }
        else
        {
            if(b>=d)
            {
                rn=b;
            }
            else
            {
                rn=d;
            }
        }
    }
    else if(d>=a&&d>=b&&d>=c)/* checking if d is the largest */ 
    {
        if(a>=b)/* finding the largest among a,b,c */
        {
            if(a>=c)
            {
                rn=a;
            }
        }
        else
        {
            if(b>=c)
            {
                rn=b;
            }
            else
            {
                rn=c;
            }
        }
    }
    
    return("The second largest number is %d",rn);/* printing the output */
    // Fill this area with your code.
    //return 0;
}
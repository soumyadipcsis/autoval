/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    /*the following for no two number equal*/
    if(a>b&&a>c&&a>d)       
        {if(b>c&&b>d)
           return("The second largest number is %d",b);
        if(c>b&&c>d)
           return("The second largest number is %d",c);
        if(d>b&&d>c)
           return("The second largest number is %d",d);}
    if(b>a&&b>c&&b>d)
       {if(a>c&&a>d)
           return("The second largest number is %d",a);
        if(c>a&&c>d)
           return("The second largest number is %d",c);
        if(d>a&&d>c)
           return("The second largest number is %d",d);}
    if(c>b&&c>a&&c>d)
       {if(b>a&&b>d)
           return("The second largest number is %d",b);
        if(a>b&&a>d)
           return("The second largest number is %d",a);
        if(d>b&&d>a)
           return("The second largest number is %d",d);}
    if(d>b&&d>c&&d>a)
       {if(b>c&&b>a)          
           return("The second largest number is %d",b);
        if(c>b&&c>a)
           return("The second largest number is %d",c);
        if(a>b&&a>c)
           return("The second largest number is %d",a);}
     /*the foolowing for any two or more equal*/
    if (a==b||a==c||a==d||b==c||b==d||c==d)
      /*when exactly two are equal and greater than other two.*/
        {if(a==b&&a>c&&a>d)
             return("The second largest number is %d",a);
        if(b==c&&b>a&&b>d)
             return("The second largest number is %d",b);
        if(c==d&&c>a&&c>b)
             return("The second largest number is %d",c);
        if(a==c&&a>b&&a>d)
             return("The second largest number is %d",a); 
        if(a==d&&a>c&&a>b)
              return("The second largest number is %d",a); 
        if(b==d&&b>a&&b>c)
              return("The second largest number is %d",b);
    /*exactly two equal and greater than one and less than the fourth*/          
          if((a==b&&a<c&&a>d)||(a==b&&a>c&&a<d))
             return("The second largest number is %d",a);
        if((b==c&&b<a&&b>d)||(b==c&&b>a&&b<d))
             return("The second largest number is %d",b);
        if((c==d&&c<a&&c>b)||(c==d&&c>a&&c<b))
             return("The second largest number is %d",c);
        if((a==c&&a<b&&a>d)||(a==c&&a>b&&a<d))
             return("The second largest number is %d",a); 
        if((a==d&&a<c&&a>b)||(a==d&&a>c&&a<b))
              return("The second largest number is %d",a); 
        if((b==d&&b<a&&b>c)||(b==d&&b>a&&b<c))
              return("The second largest number is %d",b);
        /*when exactly three are equal*/
           if(a==b&&b==c&&a!=d)
              return("The second largest number is %d",a);
        if(a==b&&b==d&&a!=c)
             return("The second largest number is %d",a);
        if(d==b&&b==c&&c!=a)
             return("The second largest number is %d",d);
        if(a==d&&d==c&&a!=b)
             return("The second largest number is %d",a);
        /*when all four are equal*/
        if(a==b&&b==c&&c==d)
             return("The second largest number is %d",a);}
    //return 0;
}
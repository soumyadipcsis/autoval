/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);/*input numbers*/
    
    if((a<=b&&b<=c&&c<=d)||(b<=a&&a<=c&&c<=d)||(d<=a&&a<=c&&c<=b)||(d<=b&&b<=c&&c<=a)||(a<=d&&d<=c&&c<=b)||(b<=d&&d<=c&&c<=a))
    /*using all permutations possible for c to be second highest*/
    {
            return("The second largest number is %d",c);
        
    }
    else if ((a<=b&&b<=d&&d<=c)||(b<=a&&a<=d&&d<=c)||(c<=a&&a<=d&&d<=b)||(c<=b&&b<=d&&d<=a)||(a<=c&&c<=d&&d<=b)||(b<=c&&c<=d&&d<=a))
    /*using all permutations possible for d to be second highest*/
    {
        return("The second largest number is %d",d);
        
    }
    else if ((c<=b&&b<=a&&a<=d)||(b<=c&&c<=a&&a<=d)||(d<=c&&c<=a&&a<=b)||(d<=b&&b<=a&&a<=c)||(c<=d&&d<=a&&a<=b)||(b<=d&&d<=a&&a<=c))
    /*using all permutations possible for a to be second highest*/
    {
        return("The second largest number is %d",a);
        
    }
    else if ((a<=c&&c<=b&&b<=d)||(c<=a&&a<=b&&b<=d)||(d<=a&&a<=b&&b<=c)||(d<=c&&c<=b&&b<=a)||(a<=d&&d<=b&&b<=c)||(c<=d&&d<=b&&b<=a))
    /*using all permutations possible for b to be second highest*/
    {
        return("The second largest number is %d",b);
        
    }
    
    //return 0;
}
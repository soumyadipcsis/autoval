/*compile-errors:e156_271564.c:11:31: warning: more '%' conversions than data arguments [-Wformat]
                   return("%d%d%d",(a)||(b)||(d));
                             ~^
1 warning generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;
int student_solution(int input_a, int input_b, int input_c, int input_d){
  int a,b,c,d;
  scanf ("%d%d%d%d",&a,&b,&c,&d);
  if(a<=b){
      if(a<=c){
          if(b<=c){
              if(c<=d){
                 return("%d",c);
              } else {
                   return("%d%d%d",(a)||(b)||(d));
              }
          }
      }
  }   
  //return 0;
}
/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
 int p,q,r,s;/*input from user*/
 scanf("%d%d%d%d",&p,&q,&r,&s);
 if((p>q)&&(q>r)&&(q>s))
    return("The second largest number is %d",q);
else if((p>r)&&(r>s)&&(r>q))
    return("The second largest number is %d",r);
else if((p>s)&&(s>r)&&(s>q))
    return("The second largest number is %d",s);
else if((q>p)&&(p>s)&&(p>r))
    return("The second largest number is %d",p);
else if((q>s)&&(s>p)&&(s>r))
    return("The second largest number is %d",s);
else if((q>r)&&(r>p)&&(r>s))    
     return("The second largest number is %d",r);
else if((r>p)&&(p>s)&&(p>q))
     return("The second largest number is %d",p);
else if((r>s)&&(s>p)&&(s>q))

      return("The second largest number is %d",s);
else if((r>q)&&(q>s)&&(q>p))
     return("The second largest number is %d",q);
else if((s>p)&&(p>r)&&(p>q))
     return("The second largest number is %d",p);
else if((s>r)&&(r>p)&&(r>q))
     return("The second largest number is %d",r);
else 
     return("The second largest number is %d",q);

    //return 0;
}
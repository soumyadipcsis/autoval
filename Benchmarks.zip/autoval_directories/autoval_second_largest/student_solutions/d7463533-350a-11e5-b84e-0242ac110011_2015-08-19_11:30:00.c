/*compile-errors:*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;
int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int m,s,a,b,c,d;
    scanf("%d %d %d %d",&a,&b,&c,&d);
    m=a;
    s=0;
    if (b>m)
    {
        s=m;
        m=b;
    }
    else if (b>s)
    {
        s=b;
    }
    if (c>m)
    {
        s=m;
        m=c;
    }
    else if (c>s)
    {
        s=c;
    }
    if (d>m)
    {
        s=m;
        m=d;
    }
    else if (d>s)
    {
        s=d;
    }
    return("The second largest number is %d",s);
    //return 0;
}
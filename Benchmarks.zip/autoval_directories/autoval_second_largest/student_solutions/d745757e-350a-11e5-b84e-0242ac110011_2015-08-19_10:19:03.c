/*compile-errors:e156_271556.c:7:18: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(a>=b&&a>=c&&a<=d||a<=b&&a>=c&&a>=d||a>=b&&a<=c&&a>=d)//Check for a
       ~~~~~~~~~~^~~~~~~~
e156_271556.c:7:18: note: place parentheses around the '&&' expression to silence this warning
    if(a>=b&&a>=c&&a<=d||a<=b&&a>=c&&a>=d||a>=b&&a<=c&&a>=d)//Check for a
                 ^
       (               )
e156_271556.c:7:36: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(a>=b&&a>=c&&a<=d||a<=b&&a>=c&&a>=d||a>=b&&a<=c&&a>=d)//Check for a
                       ~~~~~~~~~~~~^~~~~~
e156_271556.c:7:36: note: place parentheses around the '&&' expression to silence this warning
    if(a>=b&&a>=c&&a<=d||a<=b&&a>=c&&a>=d||a>=b&&a<=c&&a>=d)//Check for a
                                   ^
                         (               )
e156_271556.c:7:54: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(a>=b&&a>=c&&a<=d||a<=b&&a>=c&&a>=d||a>=b&&a<=c&&a>=d)//Check for a
                                         ~~~~~~~~~~~~^~~~~~
e156_271556.c:7:54: note: place parentheses around the '&&' expression to silence this warning
    if(a>=b&&a>=c&&a<=d||a<=b&&a>=c&&a>=d||a>=b&&a<=c&&a>=d)//Check for a
                                                     ^
                                           (               )
e156_271556.c:10:18: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(b>=a&&b>=c&&b<=d||b<=a&&b>=c&&b>=d||b>=a&&b<=c&&b>=d)//Check for b
       ~~~~~~~~~~^~~~~~~~
e156_271556.c:10:18: note: place parentheses around the '&&' expression to silence this warning
    if(b>=a&&b>=c&&b<=d||b<=a&&b>=c&&b>=d||b>=a&&b<=c&&b>=d)//Check for b
                 ^
       (               )
e156_271556.c:10:36: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(b>=a&&b>=c&&b<=d||b<=a&&b>=c&&b>=d||b>=a&&b<=c&&b>=d)//Check for b
                       ~~~~~~~~~~~~^~~~~~
e156_271556.c:10:36: note: place parentheses around the '&&' expression to silence this warning
    if(b>=a&&b>=c&&b<=d||b<=a&&b>=c&&b>=d||b>=a&&b<=c&&b>=d)//Check for b
                                   ^
                         (               )
e156_271556.c:10:54: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(b>=a&&b>=c&&b<=d||b<=a&&b>=c&&b>=d||b>=a&&b<=c&&b>=d)//Check for b
                                         ~~~~~~~~~~~~^~~~~~
e156_271556.c:10:54: note: place parentheses around the '&&' expression to silence this warning
    if(b>=a&&b>=c&&b<=d||b<=a&&b>=c&&b>=d||b>=a&&b<=c&&b>=d)//Check for b
                                                     ^
                                           (               )
e156_271556.c:13:18: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(c>=a&&c>=b&&c<=d||c<=a&&c>=b&&c>=d||c>=a&&c<=b&&c>=d)//Check for c
       ~~~~~~~~~~^~~~~~~~
e156_271556.c:13:18: note: place parentheses around the '&&' expression to silence this warning
    if(c>=a&&c>=b&&c<=d||c<=a&&c>=b&&c>=d||c>=a&&c<=b&&c>=d)//Check for c
                 ^
       (               )
e156_271556.c:13:36: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(c>=a&&c>=b&&c<=d||c<=a&&c>=b&&c>=d||c>=a&&c<=b&&c>=d)//Check for c
                       ~~~~~~~~~~~~^~~~~~
e156_271556.c:13:36: note: place parentheses around the '&&' expression to silence this warning
    if(c>=a&&c>=b&&c<=d||c<=a&&c>=b&&c>=d||c>=a&&c<=b&&c>=d)//Check for c
                                   ^
                         (               )
e156_271556.c:13:54: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(c>=a&&c>=b&&c<=d||c<=a&&c>=b&&c>=d||c>=a&&c<=b&&c>=d)//Check for c
                                         ~~~~~~~~~~~~^~~~~~
e156_271556.c:13:54: note: place parentheses around the '&&' expression to silence this warning
    if(c>=a&&c>=b&&c<=d||c<=a&&c>=b&&c>=d||c>=a&&c<=b&&c>=d)//Check for c
                                                     ^
                                           (               )
e156_271556.c:16:18: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(d>=a&&d>=b&&d<=c||d<=a&&d>=b&&d>=c||d>=a&&d<=b&&d>=c)//Check for d
       ~~~~~~~~~~^~~~~~~~
e156_271556.c:16:18: note: place parentheses around the '&&' expression to silence this warning
    if(d>=a&&d>=b&&d<=c||d<=a&&d>=b&&d>=c||d>=a&&d<=b&&d>=c)//Check for d
                 ^
       (               )
e156_271556.c:16:36: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(d>=a&&d>=b&&d<=c||d<=a&&d>=b&&d>=c||d>=a&&d<=b&&d>=c)//Check for d
                       ~~~~~~~~~~~~^~~~~~
e156_271556.c:16:36: note: place parentheses around the '&&' expression to silence this warning
    if(d>=a&&d>=b&&d<=c||d<=a&&d>=b&&d>=c||d>=a&&d<=b&&d>=c)//Check for d
                                   ^
                         (               )
e156_271556.c:16:54: warning: '&&' within '||' [-Wlogical-op-parentheses]
    if(d>=a&&d>=b&&d<=c||d<=a&&d>=b&&d>=c||d>=a&&d<=b&&d>=c)//Check for d
                                         ~~~~~~~~~~~~^~~~~~
e156_271556.c:16:54: note: place parentheses around the '&&' expression to silence this warning
    if(d>=a&&d>=b&&d<=c||d<=a&&d>=b&&d>=c||d>=a&&d<=b&&d>=c)//Check for d
                                                     ^
                                           (               )
12 warnings generated.*/
/*compile-result:1*/
/*save-event:compile*/
#include<stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int student_solution(int input_a, int input_b, int input_c, int input_d)
{
    int a,b,c,d;                        //Declaration of variables
    scanf("%d %d %d %d",&a,&b,&c,&d);   //For input by user
    if(a>=b&&a>=c&&a<=d||a<=b&&a>=c&&a>=d||a>=b&&a<=c&&a>=d)//Check for a
    return("The second largest number is %d",a);            //RESULT
    else 
    if(b>=a&&b>=c&&b<=d||b<=a&&b>=c&&b>=d||b>=a&&b<=c&&b>=d)//Check for b
    return("The second largest number is %d",b);            //RESULT
    else
    if(c>=a&&c>=b&&c<=d||c<=a&&c>=b&&c>=d||c>=a&&c<=b&&c>=d)//Check for c
    return("The second largest number is %d",c);            //RESULT
    else
    if(d>=a&&d>=b&&d<=c||d<=a&&d>=b&&d>=c||d>=a&&d<=b&&d>=c)//Check for d
    return("The second largest number is %d",d);            //RESULT
    //return 0;                                               //The End
}
#include <stdio.h>
#define scanf(str, x, y, z, w); *x=input_a;*y=input_b;*z=input_c;*w=input_d;

int golden_solution(int input_a, int input_b, int input_c, int input_d) {
	int a,b,c,d;
	scanf("%d%d%d%d" , &a, &b , &c , &d);
	int largest = -1;
	int second_largest = -1;

	if (a > largest)
		largest = a;
	else if (a > second_largest)
		second_largest = a;

	if (b > largest)
		{second_largest = largest;
		largest = b;}
	else if (b > second_largest)
		second_largest = b;

	if (c > largest)
		{second_largest = largest;
		largest = c;}
	else if (c > second_largest)
		second_largest = c;

	if (d > largest)
		{second_largest = largest;
		largest = d;}
	else if (d > second_largest)
		second_largest = d;

	return("The second largest number is %d",second_largest);

	//return 0;	
} 
python3 wrapper.py $1
rm test_case*